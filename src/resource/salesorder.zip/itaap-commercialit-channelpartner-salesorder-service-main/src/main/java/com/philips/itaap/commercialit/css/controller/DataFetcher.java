package com.philips.itaap.commercialit.css.controller;


import com.philips.itaap.commercialit.css.jpa.entity.SalesOrder;
import com.philips.itaap.commercialit.css.jpa.repository.SalesOrderRepository;
import com.philips.itaap.commercialit.css.service.DataFetcherService;
import com.philips.itaap.commercialit.css.jpa.model.SalesOrderConnection;
import com.philips.itaap.graphqlbase.common.Filter;
import com.philips.itaap.graphqlbase.common.SortingRule;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.XSlf4j;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Flux;

import java.util.List;

@XSlf4j
@Controller
@RequiredArgsConstructor
public class DataFetcher {
    private final DataFetcherService dataFetcherService;
    private final SalesOrderRepository saleOrderRepository;

    @QueryMapping
    @PreAuthorize("hasPermission('','api','api.salesorder')")
    public Flux<SalesOrderConnection> paginatedSalesOrders(@Argument int page, @Argument int size, @Argument String after,
                                                     @Argument List<Filter> filters,
                                                     @Argument SortingRule sortRule) {
        if (log.isInfoEnabled()) {
            log.info("paginatedSalesOrders() : paginatedItems requested page -> {}, size -> {}, after -> {} ", page, size, after);

        }
        return dataFetcherService.getPaginatedSalesOrders(page, size, after, filters, sortRule, saleOrderRepository, SalesOrder.class);
    }

}

