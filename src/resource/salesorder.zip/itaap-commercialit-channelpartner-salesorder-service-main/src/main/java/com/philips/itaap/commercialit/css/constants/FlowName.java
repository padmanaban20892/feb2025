package com.philips.itaap.commercialit.css.constants;

import lombok.Getter;

@Getter
public enum FlowName {

    ORDER_SERVICE("Order Service");
    final String name;
    FlowName(String name) {
        this.name = name;
    }
}