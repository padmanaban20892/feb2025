package com.philips.itaap.commercialit.css.dto;

public enum ADLEntity {
    salesOrder;

}
