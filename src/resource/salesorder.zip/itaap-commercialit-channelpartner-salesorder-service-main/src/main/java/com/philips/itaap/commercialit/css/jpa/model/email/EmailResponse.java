package com.philips.itaap.commercialit.css.jpa.model.email;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EmailResponse {
    
    private int id;
    @JsonProperty(value = "correlationID")
    private String correlationId;
    private String createdAt;
    private String to;
    private String status;
    private String failureDescription;
    private String platformName;
    private String projectName;
}
