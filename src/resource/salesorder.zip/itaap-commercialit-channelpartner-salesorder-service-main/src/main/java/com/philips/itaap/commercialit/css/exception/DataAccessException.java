package com.philips.itaap.commercialit.css.exception;

public class DataAccessException extends RuntimeException {

    private static final long serialVersionUID = 6015552880724576979L;

    public DataAccessException(String message) {

        super(message);
    }
}
