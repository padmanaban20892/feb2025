package com.philips.itaap.commercialit.css.aop;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
@SuppressWarnings("PMD")
public class ClearCacheAspect {

    private final Environment environment;
    private final CacheManager cacheManager;

    @After("@annotation(ClearCache)")
    public void clearCacheAdvice(JoinPoint point) {
        MethodSignature signature = (MethodSignature) point.getSignature();
        if (signature.getMethod().getAnnotation(Cacheable.class) != null) {
            ClearCache annotation = signature.getMethod().getAnnotation(ClearCache.class);
            String ttl = environment.resolvePlaceholders(annotation.ttl());
            ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
            scheduledExecutorService.schedule(() -> {
                log.info(String.format("Invalidating %s cache after %s", annotation.cacheName(), ttl));
                Cache cache = cacheManager.getCache(annotation.cacheName());
                if (cache != null) {
                    cache.invalidate();
                } else {
                    log.warn(" no cache found with name : {} ", annotation.cacheName());
                }

            }, Long.parseLong(ttl), TimeUnit.MINUTES);
        } else {
            log.warn("{} is not complaint with @ClearCache", point.getSignature());
        }
    }
}
