package com.philips.itaap.commercialit.css.jpa.graphqlclient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.graphql.ResponseError;

import java.util.ArrayList;
import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class QueryResultList<T> {

    private boolean failed;
    private String message;

    @Builder.Default
    private List<ResponseError> errors = new ArrayList<>();
    @Builder.Default
    private List<T> data = new ArrayList<>();

}
