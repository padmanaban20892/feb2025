package com.philips.itaap.commercialit.css.jpa.model.email;

import lombok.Data;

import java.util.List;

@Data
public class EmailRecord {
    private List<String> to;
    private List<String> cc;
    private String subject;
    private String body;
    private String platformName;
    private String projectName;
    private String priority;
}
