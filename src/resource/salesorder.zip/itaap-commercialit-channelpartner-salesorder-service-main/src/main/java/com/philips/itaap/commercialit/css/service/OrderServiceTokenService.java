package com.philips.itaap.commercialit.css.service;


import com.philips.itaap.commercialit.css.aop.ClearCache;
import com.philips.itaap.commercialit.css.config.ApplicationProperties;
import com.philips.itaap.commercialit.css.jpa.graphqlclient.TokenData;
import com.philips.itaap.commercialit.css.util.JsonMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;
import reactor.util.retry.RetryBackoffSpec;

import java.time.Duration;

import static com.philips.itaap.commercialit.css.constants.AppConstants.ORDER_JWT_TOKEN_CACHE;
import static org.springframework.security.oauth2.core.endpoint.OAuth2ParameterNames.SCOPE;
import static org.springframework.security.oauth2.core.endpoint.OAuth2ParameterNames.CLIENT_ID;
import static org.springframework.security.oauth2.core.endpoint.OAuth2ParameterNames.CLIENT_SECRET;
import static org.springframework.security.oauth2.core.endpoint.OAuth2ParameterNames.GRANT_TYPE;

import static reactor.netty.Metrics.SUCCESS;

@Slf4j
@Service
@RequiredArgsConstructor
@SuppressWarnings({"CPD-START"})
public class OrderServiceTokenService {

    private final WebClient orderServiceWebClient;
    private final ApplicationProperties applicationProperties;
    @Value("${spring.security.oauth2.client.provider.order.token-uri}")
    private String tokenUri;
    @Value("${spring.security.oauth2.client.registration.order.client-id}")
    private String clientId;
    @Value("${spring.security.oauth2.client.registration.order.client-secret}")
    private String clientSecret;
    @Value("${spring.security.oauth2.client.registration.order.authorization-grant-type}")
    private String authorizationGrantType;

    @Value("${spring.security.oauth2.client.registration.order.scope}")
    private String scope;

    @Cacheable(value = ORDER_JWT_TOKEN_CACHE, key = "#root.methodName")
    @ClearCache(cacheName = ORDER_JWT_TOKEN_CACHE, ttl = "${cache.ttl.orderToken}")
    public Mono<TokenData> getOrderServiceToken() {
        log.info("Start getOrderServiceToken()");
        return orderServiceWebClient
                .post()
                .uri(tokenUri)
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .body(BodyInserters.fromFormData(GRANT_TYPE, authorizationGrantType)
                        .with(CLIENT_ID, clientId)
                        .with(CLIENT_SECRET, clientSecret)
                        .with(SCOPE, scope))
                .accept(MediaType.APPLICATION_JSON)
                .exchangeToMono(clientResponse -> {
                    if (clientResponse.statusCode().isError()) {
                        return handleErrorResponse(clientResponse);
                    } else {
                        return handleSuccessResponse(clientResponse);
                    }
                });
    }

    private Mono<TokenData> handleErrorResponse(ClientResponse clientResponse) {
        return clientResponse.bodyToMono(String.class)
                .map(error -> {
                    log.error("getOrderServiceToken() : Error Occurred [{}] while fetching token. Error -> {}", clientResponse.statusCode(), error);
                    return TokenData.builder()
                            .failed(true)
                            .message(error)
                            .build();
                });
    }

    private Mono<TokenData> handleSuccessResponse(ClientResponse clientResponse) {
        return clientResponse.bodyToMono(String.class)
                .map(tokenResponse -> {
                    log.debug("getOrderServiceToken() -> tokenResponse :  {}", tokenResponse);
                    log.info("getOrderServiceToken() -> within the success block");

                    TokenData tokenOrder = JsonMapper.readValue(tokenResponse, TokenData.class);
                    if (tokenOrder == null) {
                        log.info("getOrderServiceToken() -> error while parsing token ");
                        return TokenData.builder()
                                .failed(true)
                                .message("error while parsing token ")
                                .build();
                    }
                    tokenOrder.setFailed(false);
                    tokenOrder.setMessage(SUCCESS);
                    return tokenOrder;
                });
    }

    public RetryBackoffSpec getRetrySpec(String info) {
        return Retry.backoff(applicationProperties.getMaxRetry(),
                        Duration.ofSeconds(applicationProperties.getDelay()))
                .jitter(0.2)
                .doBeforeRetry(retrySignal -> log.info("Retrying {} attempt [{}] ", info, retrySignal.totalRetries() + 1))
                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> retrySignal.failure());
    }

}
