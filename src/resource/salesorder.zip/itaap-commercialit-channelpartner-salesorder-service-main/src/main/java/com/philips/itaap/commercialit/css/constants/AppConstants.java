package com.philips.itaap.commercialit.css.constants;

public class AppConstants {
    public static final String SALE_ORDER_DATA = "t_mom_sales_order_line_data_p4p";
    public static final String UNABLE_TO_ACCESS_DATA = "Unable to Access Data";
    public static final String PAGE_NO = "PAGE_NO";
    public static final String PAGE_SIZE = "PAGE_SIZE";
    public static final String FILTER = "FILTER";
    public static final String SORT_RULE = "SORT_RULE";
    public static final String EXCEPTION = "EXCEPTION";
    public static final String TRACER_ID = "TRACER_ID";
    public static final String CORRELATION_ID = "CORRELATION_ID";
    public static final String QUERY_NAME = "QUERY_NAME";

    public static final String SALE_ORDER_ITEM = "saleOrderItem";

    public static final String SKIPPED = "SKIPPED";
    public static final String FAILED = "FAILED";


    public static final String EMAIL_DATA = "email-data";

    public static final String EMAIL_PROJECT_NAME = "Channel Partner Sales Order";
    public static final String EMAIL_PLATFORM_NAME = "ITaaP";

    public static final String ORDER_JWT_TOKEN_CACHE = "ORDER_JWT_TOKEN_CACHE";

    public static final String MYP4P = "MyP4P";

    public static final String COLON  = ":";

    public static final String DECIMAL_FORMAT = "####.00";

    public static final String DATE_PATTERN = "yyyy-MM-dd";

    public static final Double ZERO = 0.0;

    public static final String PHILIPSORDERNO = "philipsOrderNo";

    public static final String PHILIPS_ORDER_NUMBER_ENTITY = "Philips_Order_Number";

    public static final String DISTINCT_QUERY = "SELECT DISTINCT so.Philips_Order_Number FROM qa_gold.o2c.t_mom_sales_order_line_data_p4p so ";

    public static final String WHERE = " WHERE ";

    public static final String AND = " AND ";

    public static final String PARTNER_PO = " so.Customer_Purchase_Order_Number in (:partnerPO) ";

    public static final String SOLD_TO_NO = " so.Sold_To_Number in (:soldNo) ";

    public static final String PHILIPS_ORDER_NO = " so.Philips_Order_Number in (:philipsOrderNo) ";

    public static final String SALES_ORDER_DATE = " so.SalesOrder_Date BETWEEN :startDate AND :endDate  ";







}