package com.philips.itaap.commercialit.css.jpa.model;


import com.philips.itaap.commercialit.css.jpa.entity.SalesOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SalesOrderConnection {
    private PageInfo pageInfo;
    private List<SalesOrder> salesOrders;

}
