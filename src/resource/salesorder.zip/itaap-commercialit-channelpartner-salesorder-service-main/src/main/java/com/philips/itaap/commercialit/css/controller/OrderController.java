package com.philips.itaap.commercialit.css.controller;

import com.philips.itaap.commercialit.css.config.ApplicationProperties;
import com.philips.itaap.commercialit.css.jpa.model.OrdersDto;
import com.philips.itaap.commercialit.css.jpa.model.OrdersResponse;
import com.philips.itaap.commercialit.css.service.OrderService;
import com.philips.itaap.commercialit.css.util.JsonMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.XSlf4j;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;


@RestController
@RequiredArgsConstructor
@XSlf4j
public class OrderController {

    private final OrderService orderService;
    private final ApplicationProperties applicationProperties;

    @PreAuthorize("hasPermission('','post','post.sales-order')")
    @PostMapping(value = "${api.order.fetchOrders}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Flux<OrdersResponse> ordersDetail(@RequestBody OrdersDto ordersDto) {

        if (log.isInfoEnabled()) {
            log.info("------------------------------------------------------------");
            log.info("ordersDetail() : getting the data  {}", JsonMapper.fromObjectToJson(ordersDto));
        }
         return orderService.ordersDetail(ordersDto, applicationProperties.getApiFetchOrdersDetails());
    }




}
