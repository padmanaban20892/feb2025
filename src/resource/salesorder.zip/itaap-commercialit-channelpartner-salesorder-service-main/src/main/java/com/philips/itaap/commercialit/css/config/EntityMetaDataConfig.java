package com.philips.itaap.commercialit.css.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.XSlf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import com.philips.itaap.commercialit.css.dto.ADLEntity;
import com.philips.itaap.commercialit.css.dto.EntityMetaData;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@ConfigurationProperties(prefix = "adlentity")
@Data
@XSlf4j
public class EntityMetaDataConfig {
    String metadata;

    Map<ADLEntity, EntityMetaData> entityMetaDataMap;

    public void loadMetaData() {
        List<EntityMetaData> entityList = parse(metadata);
        entityMetaDataMap = entityList.stream().collect(Collectors.toMap(e -> ADLEntity.valueOf(e.getEntity()), e -> e));
    }

    public static List<EntityMetaData> parse(String input) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            if (log.isInfoEnabled()) {
                log.info("Input metadata array -> {}", input);
            }
            return objectMapper.readValue(input.replaceAll("\\\\", null), new TypeReference<>() {
            }); //unescape JSON string
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("{} -> {}", e, e.getMessage());
            }
            return null;
        }
    }

    public EntityMetaData getMetaData(ADLEntity entityName) {
        if (entityMetaDataMap == null) {
            loadMetaData();
        }
        return entityMetaDataMap.get(entityName);
    }
}
