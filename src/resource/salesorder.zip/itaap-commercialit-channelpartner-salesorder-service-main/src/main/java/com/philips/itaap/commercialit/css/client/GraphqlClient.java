package com.philips.itaap.commercialit.css.client;

import com.philips.itaap.commercialit.css.jpa.graphqlclient.QueryResult;
import com.philips.itaap.commercialit.css.jpa.graphqlclient.QueryResultList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.graphql.client.ClientResponseField;
import org.springframework.graphql.client.HttpGraphQlClient;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * @ Author :Pravin Kumbhar
 */

@Slf4j
@SuppressWarnings({"CPD-START"})
public abstract class GraphqlClient {

    private final HttpGraphQlClient httpGraphQlClient;
    private final String url;

    protected GraphqlClient(HttpGraphQlClient httpGraphQlClient, String url) {
        this.httpGraphQlClient = httpGraphQlClient;
        this.url = url;
    }

    protected Mono<HttpGraphQlClient> getHttpGraphQlClient(Map<String, String> headers) {
        return Mono.deferContextual(ctx -> Mono.just(httpGraphQlClient.mutate().url(url)
                .headers(httpHeaders -> headers.forEach(httpHeaders::add))
                .build()));
    }


    protected <T> Mono<QueryResult<T>> getQueryResultByDocumentName(Map<String, String> headers, String documentName, String path,
                                                                    Map<String, Object> variables,
                                                                    ParameterizedTypeReference<T> entityType) {
        return getHttpGraphQlClient(headers)
                .flatMap(graphQlClient -> graphQlClient.documentName(documentName)
                        .variables(variables)
                        .execute())
                .map(graphQlResponse -> {
                    if (!graphQlResponse.isValid()) {
                        return QueryResult.<T>builder().errors(graphQlResponse.getErrors()).build();
                    }
                    ClientResponseField field = graphQlResponse.field(path);
                    if (!field.getErrors().isEmpty()) {
                        return QueryResult.<T>builder().errors(field.getErrors()).build();
                    } else {
                        return QueryResult.<T>builder().data(field.toEntity(entityType)).build();
                    }

                });
    }

    protected <T> Mono<QueryResultList<T>> getQueryResultListByDocumentName(Map<String, String> headers, String documentName, String path,
                                                                            Map<String, Object> variables,
                                                                            ParameterizedTypeReference<T> entityType) {
        return getHttpGraphQlClient(headers)
                .flatMap(graphQlClient -> graphQlClient.documentName(documentName)
                        .variables(variables)
                        .execute())
                .map(graphQlResponse -> {
                    if (!graphQlResponse.isValid()) {
                        return QueryResultList.<T>builder().errors(graphQlResponse.getErrors()).build();
                    }
                    ClientResponseField field = graphQlResponse.field(path);
                    if (!field.getErrors().isEmpty()) {
                        return QueryResultList.<T>builder().errors(field.getErrors()).build();
                    } else {
                        return QueryResultList.<T>builder().data(field.toEntityList(entityType)).build();
                    }

                });
    }

}