package com.philips.itaap.commercialit.css.jpa.compositekey;

import lombok.Data;

import java.io.Serializable;

@Data
public class SalesOrderKey implements Serializable {
    private static final long serialVersionUID = 194342324688795L;

    private String soldToNo;
    private String customerPurchaseOrderNo;
    private String philipsOrderNo;
   private String saleOrderItem;
}
