package com.philips.itaap.commercialit.css.jpa.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.philips.itaap.commercialit.css.constants.AppConstants;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class LineItems implements Serializable {


    private static final long serialVersionUID = 8600739057340254218L;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = AppConstants.DATE_PATTERN)
    private String invoiceDate;

    private String invoiceNumber;

   // private long invoiceNumberCountPerLineItem; //add new column refer purpose

    private List<InvoiceNumberSpecificLineItems> invoiceNumberSpecificLineItems;

}
