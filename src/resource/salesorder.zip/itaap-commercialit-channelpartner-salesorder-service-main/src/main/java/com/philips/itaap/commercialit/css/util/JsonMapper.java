package com.philips.itaap.commercialit.css.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.TraceContext;
import org.springframework.cloud.sleuth.Tracer;

import java.util.Optional;


@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class JsonMapper {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper()
            .findAndRegisterModules().configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);


    public static <T> String fromObjectToJson(T object) {
        if (object != null) {
            try {
                return MAPPER.writeValueAsString(object);
            } catch (Exception e) {
                if (log.isErrorEnabled()) {
                    log.error("Error occurred [{}] while converting to string [{}]", e.getMessage(), object);
                }
            }
        }
        return StringUtils.EMPTY;
    }

    public static String getTraceId(Tracer tracer) {
        return Optional.ofNullable(tracer.currentSpan())
                .map(Span::context)
                .map(TraceContext::traceId)
                .orElseGet(() -> {
                    Span span = tracer.nextSpan();
                    return span.context().traceId();
                });

    }

    public static <T> T readValue(String content, Class<T> valueType) {
        if (log.isDebugEnabled()) {
            log.debug("readValue() : BEFORE TRANSFORMATION : inputMessage -> {}", content);
        }
        T output = null;
        try {
            output = OBJECT_MAPPER.readValue(content, valueType);
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("readValue() : Error occurred [{}] while reading from string -> {}", e.getMessage(), content);
            }
        }
        if (log.isDebugEnabled()) {
            log.debug("readValue() : AFTER TRANSFORMATION : outputMessage -> {}", output);
        }
        return output;
    }
}
