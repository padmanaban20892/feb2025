package com.philips.itaap.commercialit.css.jpa.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class SoldToParty implements Serializable {

    private static final long serialVersionUID = 2166436895350138132L;
    private String partnerNumber;

    private String name;
}
