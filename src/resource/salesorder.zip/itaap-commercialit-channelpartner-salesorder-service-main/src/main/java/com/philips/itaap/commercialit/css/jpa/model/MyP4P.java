package com.philips.itaap.commercialit.css.jpa.model;

import lombok.Data;

@Data
public class MyP4P {
    public Find find;
}