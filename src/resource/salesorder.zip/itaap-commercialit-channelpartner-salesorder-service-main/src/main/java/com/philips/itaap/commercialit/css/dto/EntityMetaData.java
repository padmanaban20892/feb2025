package com.philips.itaap.commercialit.css.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EntityMetaData {
    private String entity;
    private String table;
    private String schema;
}
