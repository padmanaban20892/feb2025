package com.philips.itaap.commercialit.css.jpa.repository;

import com.philips.itaap.commercialit.css.constants.AppConstants;
import com.philips.itaap.commercialit.css.jpa.entity.SalesOrder;
import com.philips.itaap.graphqlbase.common.OLAPRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.graphql.data.GraphQlRepository;

import java.util.Date;
import java.util.List;


@GraphQlRepository
@SuppressWarnings({"CPD-START"})
public interface SalesOrderRepository extends OLAPRepository<SalesOrder, String> {


    @Query(value = AppConstants.DISTINCT_QUERY, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNumberBySalesOrderNumber(Pageable pageable);

    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.SOLD_TO_NO, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoBySoldToNo(@Param("soldNo") List<String> soldNo, Pageable pageable);


    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PHILIPS_ORDER_NO, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoByPhilipsOrderNo(@Param("philipsOrderNo") List<String> philipsOrderNo, Pageable pageable);

    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PARTNER_PO, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoByCustomerPurchaseOrderNo(@Param("partnerPO") List<String> partnerPO, Pageable pageable);


    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.SALES_ORDER_DATE, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoBySalesOrderDate(@Param("startDate") Date startDate,
                                                            @Param("endDate") Date endDate, Pageable pageable);


    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PHILIPS_ORDER_NO + AppConstants.AND
            + AppConstants.PARTNER_PO, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoByPhilipsOrderNoCustomerPurchaseOrderNo(@Param("philipsOrderNo") List<String> philipsOrderNo,
                                                                                   @Param("partnerPO") List<String> partnerPO, Pageable pageable);


    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PHILIPS_ORDER_NO + AppConstants.AND
            + AppConstants.SOLD_TO_NO, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoByPhilipsOrderNoSoldToNo(@Param("philipsOrderNo") List<String> philipsOrderNo,
                                                                    @Param("soldNo") List<String> soldNo, Pageable pageable);


    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PARTNER_PO + AppConstants.AND
            + AppConstants.SOLD_TO_NO, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoByCustomerPurchaseOrderNoSoldToNo(@Param("partnerPO") List<String> partnerPO,
                                                                             @Param("soldNo") List<String> soldNo, Pageable pageable);


    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PHILIPS_ORDER_NO + AppConstants.AND
            + AppConstants.PARTNER_PO + AppConstants.AND + AppConstants.SOLD_TO_NO, nativeQuery = true)
    Page<String> findDistinctPhilipsOrdNoByAllWithoutDate(@Param("partnerPO") List<String> partnerPO,
                                                          @Param("soldNo") List<String> soldNo,
                                                          @Param("philipsOrderNo") List<String> philipsOrderNo,
                                                          Pageable pageable);

    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.SOLD_TO_NO
            + AppConstants.AND + AppConstants.SALES_ORDER_DATE, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoBySoldToNoWithDate(@Param("soldNo") List<String> soldNo, @Param("startDate") Date startDate,
                                                              @Param("endDate") Date endDate,
                                                              Pageable pageable);


    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PHILIPS_ORDER_NO + AppConstants.AND
            + AppConstants.SALES_ORDER_DATE, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoByPhilipsOrdNoWithDate(@Param("philipsOrderNo") List<String> soldToNo,
                                                                  @Param("startDate") Date startDate,
                                                                  @Param("endDate") Date endDate, Pageable pageable);

    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PARTNER_PO + AppConstants.AND
            + AppConstants.SALES_ORDER_DATE, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoByCustomerPurchaseOrderNoWithDate(@Param("partnerPO") List<String> partnerPO,
                                                                             @Param("startDate") Date startDate,
                                                                             @Param("endDate") Date endDate, Pageable pageable);


    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PHILIPS_ORDER_NO + AppConstants.AND
            + AppConstants.PARTNER_PO + AppConstants.AND + AppConstants.SALES_ORDER_DATE, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoByPhilipsOrderNoCustomerPurchaseOrderNoSODate(@Param("philipsOrderNo") List<String> philipsOrderNo,
                                                                                         @Param("partnerPO") List<String> partnerPO, @Param("startDate") Date startDate,
                                                                                         @Param("endDate") Date endDate, Pageable pageable);


    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PHILIPS_ORDER_NO + AppConstants.AND
            + AppConstants.SOLD_TO_NO + AppConstants.AND + AppConstants.SALES_ORDER_DATE, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoByPhilipsOrderNoSoldToNoSODate(@Param("philipsOrderNo") List<String> philipsOrderNo,
                                                                          @Param("soldNo") List<String> soldNo, @Param("startDate") Date startDate,
                                                                          @Param("endDate") Date endDate, Pageable pageable);


    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PARTNER_PO + AppConstants.AND
            + AppConstants.SOLD_TO_NO + AppConstants.AND + AppConstants.SALES_ORDER_DATE, nativeQuery = true)
    Page<String> findDistinctPhilipsOrderNoByCustomerPurchaseOrderNoSoldToNoSODate(@Param("partnerPO") List<String> partnerPO,
                                                                                   @Param("soldNo") List<String> soldNo, @Param("startDate") Date startDate,
                                                                                   @Param("endDate") Date endDate, Pageable pageable);

    @Query(value = AppConstants.DISTINCT_QUERY + AppConstants.WHERE + AppConstants.PHILIPS_ORDER_NO + AppConstants.AND + AppConstants.PARTNER_PO + AppConstants.AND
            + AppConstants.SOLD_TO_NO + AppConstants.AND + AppConstants.SALES_ORDER_DATE, nativeQuery = true)
    Page<String> findDistinctPhilipsOrdNoByAll(@Param("soldNo") List<String> soldNo,
                                               @Param("partnerPO") List<String> partnerPO,
                                               @Param("philipsOrderNo") List<String> philipsOrderNo, @Param("startDate") Date startDate,
                                               @Param("endDate") Date endDate, Pageable pageable);

}