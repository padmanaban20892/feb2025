package com.philips.itaap.commercialit.css.jpa.model;

import lombok.Data;

import java.util.List;

@Data
public class Find {

    public boolean hasMoreItems;
    public Long totalNumberOfRecords;
    public float requestCharge;
    public List<Orders> orders;
}
