package com.philips.itaap.commercialit.css.config;

import com.philips.itaap.ms.dev.base.exception.ServiceException;
import io.netty.resolver.DefaultAddressResolverGroup;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.graphql.client.HttpGraphQlClient;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.security.oauth2.client.AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientProvider;
import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientProviderBuilder;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.util.retry.Retry;

import java.time.Duration;

@Slf4j
@Configuration
@RequiredArgsConstructor
@SuppressWarnings({"CPD-START", "PMD.DoNotUseThreads"})
public class WebClientConfig {


    private final ApplicationProperties applicationProperties;


    @Bean
    public ReactiveOAuth2AuthorizedClientManager authorizedClientManager(ReactiveClientRegistrationRepository clientRegistrationRepository, ReactiveOAuth2AuthorizedClientService authorizedClientService) {

        ReactiveOAuth2AuthorizedClientProvider authorizedClientProvider = ReactiveOAuth2AuthorizedClientProviderBuilder.builder().clientCredentials().build();
        AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager authorizedClientManager = new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(clientRegistrationRepository, authorizedClientService);
        authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider);

        return authorizedClientManager;
    }

    @Bean
    WebClient webClientEmail(ReactiveOAuth2AuthorizedClientManager authorizedClientManager) {
        ServerOAuth2AuthorizedClientExchangeFilterFunction oAuth2Client = new ServerOAuth2AuthorizedClientExchangeFilterFunction(authorizedClientManager);
        oAuth2Client.setDefaultClientRegistrationId("email");
        return getWebClient(oAuth2Client);
    }


    private WebClient getWebClient(ServerOAuth2AuthorizedClientExchangeFilterFunction oAuth) {
        return WebClient.builder()
                .codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(applicationProperties.getMemoryBufferSize()))
                .clientConnector(new ReactorClientHttpConnector(getHttpClient()))
                .filter(logRequest())
                .filter(oAuth)
                .build();
    }

    private HttpClient getHttpClient() {
        return HttpClient
                .create()
                .keepAlive(false)
                .resolver(DefaultAddressResolverGroup.INSTANCE)
                .responseTimeout(Duration.ofSeconds(applicationProperties.getTimeout()));
    }

    /**
     * Log request for debugging purposes.
     */

    private ExchangeFilterFunction logRequest() {
        return ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
            if (log.isDebugEnabled()) {
                log.debug("logRequest() : Request -> {} : {}", clientRequest.method(), clientRequest.url());
            }
            clientRequest.headers().forEach((name, values) -> values.forEach(value -> {
                if (log.isDebugEnabled()) {
                    log.debug("{} : {}", name, value);
                }
            }));
            return Mono.just(clientRequest);
        });
    }

    /**
     * This method is used to implement Retry with maximum no of attempts and delay of seconds as specified
     * in property file and throws exception when maximum attempts reached.
     *
     * @return Retry
     */
    @Bean
    public Retry attemptRetry() {
        return Retry.backoff(applicationProperties.getMaxRetry(), Duration.ofSeconds(applicationProperties.getDelay()))
                .filter(throwable -> throwable instanceof ServiceException && ((ServiceException) throwable).getStatus().is5xxServerError())
                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> {
                    ServiceException se = (ServiceException) retrySignal.failure();
                    throw new ServiceException(se.getStatus(), se.getStatus().value(), se.getReason());
                });
    }

    @Bean
    WebClient orderServiceWebClient(ReactiveOAuth2AuthorizedClientManager authorizedClientManager) {
        return WebClient.builder()
                .codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
                .clientConnector(new ReactorClientHttpConnector(getHttpClient()))
                .filter(logRequest())
                .build();
    }

    @Bean
    public HttpGraphQlClient orderServiceHttpGraphQlClient(WebClient orderServiceWebClient) {
        return HttpGraphQlClient.builder(orderServiceWebClient).build();
    }

}
