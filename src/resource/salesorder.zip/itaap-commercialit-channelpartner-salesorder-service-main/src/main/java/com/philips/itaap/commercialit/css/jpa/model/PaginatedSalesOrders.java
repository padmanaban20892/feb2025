package com.philips.itaap.commercialit.css.jpa.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.philips.itaap.commercialit.css.jpa.entity.SalesOrder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaginatedSalesOrders {
    @JsonProperty("pageInfo")
    private PageInfo pageInfo;
    private List<SalesOrder> salesOrders;

}
