package com.philips.itaap.commercialit.css.service;


import com.philips.itaap.commercialit.css.config.ApplicationProperties;
import com.philips.itaap.commercialit.css.constants.AppConstants;
import com.philips.itaap.commercialit.css.jpa.entity.SalesOrder;
import com.philips.itaap.commercialit.css.jpa.model.Orders;
import com.philips.itaap.commercialit.css.jpa.model.OrdersDto;
import com.philips.itaap.commercialit.css.jpa.model.OrdersResponse;
import com.philips.itaap.commercialit.css.jpa.model.MyP4P;
import com.philips.itaap.commercialit.css.jpa.model.Data;
import com.philips.itaap.commercialit.css.jpa.model.LineItems;
import com.philips.itaap.commercialit.css.jpa.model.InvoiceNumberSpecificLineItems;
import com.philips.itaap.commercialit.css.jpa.model.Find;
import com.philips.itaap.commercialit.css.jpa.model.SoldToParty;
import com.philips.itaap.commercialit.css.jpa.model.email.CPMSummary;
import com.philips.itaap.commercialit.css.jpa.model.SalesOrderConnection;
import com.philips.itaap.commercialit.css.jpa.repository.SalesOrderRepository;
import com.philips.itaap.commercialit.css.util.JsonMapper;
import com.philips.itaap.graphqlbase.common.Filter;
import com.philips.itaap.graphqlbase.common.QueryOperator;
import com.philips.itaap.graphqlbase.common.SortingRule;
import com.philips.itaap.ms.dev.base.exception.ServiceException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Calendar;
import java.util.Set;
import java.util.ArrayList;
import java.util.Currency;
import java.util.Locale;
import java.util.HashMap;


import static com.philips.itaap.commercialit.css.constants.AppConstants.MYP4P;
import static com.philips.itaap.commercialit.css.constants.FlowName.ORDER_SERVICE;
import static com.philips.itaap.commercialit.css.util.JsonMapper.getTraceId;
import static org.springframework.util.CollectionUtils.isEmpty;

@Slf4j
@Service
@RequiredArgsConstructor
@SuppressWarnings({"PMD.ExcessiveImports", "PMD.PreserveStackTrace", "CPD-START", "PMD.UnnecessaryFullyQualifiedName", "PMD.UselessParentheses"})
public class OrderService {

    private final ApplicationProperties applicationProperties;
    private final Tracer tracer;
    private final DataFetcherService dataFetcherService;
    private final SalesOrderRepository saleOrderRepository;
    private final EmailService emailService;

    public Flux<OrdersResponse> ordersDetail(OrdersDto ordersDto, String apiFetchOrdersDetails) {
        if (log.isInfoEnabled()) {
            log.info(" ordersDetail() : received data -> {}", ordersDto);
        }
        CPMSummary summary = CPMSummary.builder()
                .correlationId(getTraceId(tracer))
                .startTime(Calendar.getInstance().getTime().toString())
                .flowName(ORDER_SERVICE.getName())
                .sourceSystem(MYP4P)
                .endpoint(apiFetchOrdersDetails)
                .failed(false)
                .build();
        String errorMessage = " Orders Details cannot be null";
        try {

            if (dateValidator(ordersDto)) {
                log.error("ordersDetail() : Invalid date range: Start Date should not be greater than End Date");
                errorMessage = " Start Date should not be greater than End Date";
                throw new IllegalArgumentException(" Start Date should not be greater than End Date");
            }

            String startDate = ordersDto.getParameters().getStartDate();
            String endDate = ordersDto.getParameters().getEndDate();
            if ((startDate != null && endDate == null) || (startDate == null && endDate != null)) {
                errorMessage = " Start Date or End Date field is missing";
                throw new IllegalArgumentException(" Invalid date : one date field is missing");
            }

            return Flux.just(ordersDto)
                    .flatMapSequential(this::ordersDetailsFromSalesOrderService)
                    .collectList()
                    .map(salesOrders -> processSaleOrderDetails(salesOrders, summary))
                    .flatMapIterable(list -> list);
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("ordersDetail() : Error occurred while orders Detail  -> {}", e.getMessage(), e);
            }
            //createSupportEmail(1, applicationProperties.getLimit(), JsonMapper.fromObjectToJson(ordersDto), OrdersDto.class, "", AppConstants.FAILED + " : Orders Details cannot be null");
            throw new ServiceException(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value(), errorMessage);
        }
    }
    private boolean dateValidator(OrdersDto ordersDto) {
        if (log.isDebugEnabled()) {
            log.debug(" dateValidator : received data -> {}", ordersDto);
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        String start = ordersDto.getParameters().getStartDate();
        String end = ordersDto.getParameters().getEndDate();

        if (start != null && end != null) {
            LocalDate startDate = LocalDate.parse(start, formatter);
            LocalDate endDate = LocalDate.parse(end, formatter);
            return endDate.isBefore(startDate);
        } else {
            return false;
        }
    }
    private Mono<SalesOrderConnection> ordersDetailsFromSalesOrderService(OrdersDto orderDto) {
        if (log.isInfoEnabled()) {
            log.info(" ordersDetailsFromSalesOrderService() : received data -> {}", orderDto);
        }
        SortingRule sortingRule = null;
        int page = 0;
        int size = 0;
        List<Filter> filterList = new ArrayList<>();
        try {


            page = orderDto.getParameters().getOffSet();
            size = applicationProperties.getLimit();

            if (orderDto.getParameters().getSoldToPartnerNumber() != null) {
                filterList.add(filterBuilder("soldToNo", orderDto.getParameters().getSoldToPartnerNumber()));
                //Sold_To_Number - soldToNo
            }
            if (orderDto.getParameters().getPartnerPO() != null) {
                filterList.add(filterBuilder("customerPurchaseOrderNo", orderDto.getParameters().getPartnerPO()));
                //Customer_Purchase_Order_Number - customerPurchaseOrderNo
            }
            if (orderDto.getParameters().getSalesOrder() != null) {
                filterList.add(filterBuilder("philipsOrderNo", orderDto.getParameters().getSalesOrder()));
                //Philips_Order_Number - philipsOrderNo
            }
            if (orderDto.getParameters().getStartDate() != null) {
                filterList.add(filterBuilderValue("salesOrderDate", orderDto.getParameters().getStartDate(), orderDto.getParameters().getEndDate()));
            }

            return dataFetcherService.getSaleOrderByADLWithNativeQuery(page,
                    size, filterList,  saleOrderRepository, SalesOrder.class, orderDto);

        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("ordersDetailsFromSalesOrderService() : sales order details Integration : Error occurred while sales order service  -> {}",
                        e.getMessage(), e);
            }
            createSupportEmail(page, size, JsonMapper.fromObjectToJson(filterList), SalesOrder.class, JsonMapper.fromObjectToJson(sortingRule), AppConstants.FAILED + " : Sales Order  Details cannot be null or empty");
            throw new ServiceException(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value(), "sales order details cannot be null or empty");
        }
    }

    private List<OrdersResponse> processSaleOrderDetails(List<SalesOrderConnection> salesOrderConnections, CPMSummary summary) {

        if (log.isInfoEnabled()) {
            log.info("---------------------process SaleOrder Details  Started-----------------------");
        }
        if (isEmpty(salesOrderConnections)) {
            if (log.isInfoEnabled()) {
                log.info("processSaleOrderDetails() : No order details received from salesOrder service ");
            }
            throw new ServiceException(HttpStatus.OK, HttpStatus.OK.value(), "No order details received from salesOrder service");
        } else {
            salesOrderConnections.forEach(
                    order -> {
                        if (isEmpty(order.getSalesOrders())) {
                            if (log.isInfoEnabled()) {
                                log.info("processSaleOrderDetails() : No order details received from salesOrder service ");
                            }
                            throw new ServiceException(HttpStatus.OK, HttpStatus.OK.value(), "No order details from salesOrder ");
                        }
                    }
            );
        }
        if (log.isDebugEnabled()) {
            log.info("processSaleOrderDetails() : received data from salesOrder service :{} ", salesOrderConnections);
        }
        return convertOrdersFromSalesOrderList(salesOrderConnections, summary);

    }


    private List<OrdersResponse> convertOrdersFromSalesOrderList(List<SalesOrderConnection> salesOrderConnections, CPMSummary summary) {
        if (log.isInfoEnabled()) {
            log.info("convertOrdersFromSalesOrderList() :  Processing the sales order into orders data");
        }

        List<OrdersResponse> ordersResponseList = new ArrayList<>();
        Map<String, List<Double>> ordersValueMap = new HashMap<>();
        Map<String, String> currencySymbolMap = new HashMap<>();
        OrdersResponse ordersResponse = new OrdersResponse();

        try {

            Map<String, String> countryBySymbol = countryCodeToCurrencySymbol();
            if (log.isDebugEnabled()) {
                log.info("calculationOrderItems() : currencySymbolMap {}", countryBySymbol);
            }
            MyP4P myP4P = new MyP4P();
            Find find = new Find();
            List<Orders> ordersList = new ArrayList<>();
            List<Orders> newOrders = new ArrayList<>();

            salesOrderConnections.forEach(
                    saleOrderList -> {
                        if (log.isDebugEnabled()) {
                            log.info("convertOrdersFromSalesOrderList() : List of sales order :{}", saleOrderList.getSalesOrders().size());
                        }
                        saleOrderList.getSalesOrders().forEach(salesOrder -> {
                            String currencySymbol = countryBySymbol.get(salesOrder.getCurrency());
                            boolean isUpdated = false;

                            // Check and update existing orders in ordersList
                            for (Orders orders : ordersList) {
                                if (orders.getPartnerPO().equals(salesOrder.getCustomerPurchaseOrderNo())
                                        && orders.getSoldToParty().getPartnerNumber().equals(salesOrder.getSoldToNo())
                                        && orders.getSalesOrder().equals(salesOrder.getPhilipsOrderNo())) {
                                    updateOrderWithLineItem(orders, salesOrder, currencySymbol, ordersValueMap, currencySymbolMap);
                                    isUpdated = true;
                                    break;
                                }
                            }

                            // If not found in ordersList, check in newOrders
                            if (!isUpdated) {
                                for (Orders newOrder : newOrders) {
                                    if (newOrder.getPartnerPO().equals(salesOrder.getCustomerPurchaseOrderNo())
                                            && newOrder.getSoldToParty().getPartnerNumber().equals(salesOrder.getSoldToNo())
                                            && newOrder.getSalesOrder().equals(salesOrder.getPhilipsOrderNo())) {
                                        updateOrderWithLineItem(newOrder, salesOrder, currencySymbol, ordersValueMap, currencySymbolMap);
                                        isUpdated = true;
                                        break;
                                    }
                                }
                            }

                            // If not found in either, add it as a new order
                            if (!isUpdated) {
                                newOrders.add(getOrdersFromSalesOrders(salesOrder, currencySymbol, ordersValueMap, currencySymbolMap));
                            }
                        });
                        ordersList.addAll(newOrders);
                        if (saleOrderList.getPageInfo() != null) {
                            //find.setCursor(saleOrderList.getPageInfo().getEndCursor());
                            find.setHasMoreItems(saleOrderList.getPageInfo().getHasNextPage());
                            find.setTotalNumberOfRecords(saleOrderList.getPageInfo().getTotalNumberOfRecords());
                        }
                    }
            );

            if (log.isDebugEnabled()) {
                log.info("convertOrdersFromSalesOrderList() : List of sales order size :{}", ordersList.size());
            }

            find.setOrders(calculationOrderItems(ordersList, ordersValueMap, currencySymbolMap));
            find.setRequestCharge(0);
            myP4P.setFind(find);
            Data data = new Data();
            data.setMyP4P(myP4P);
            ordersResponse.setData(data);
            ordersResponseList.add(ordersResponse);

            if (log.isInfoEnabled()) {
                log.info(" Orders response list conversion from the sales order service is successful");
            }
            return ordersResponseList;
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("convertOrdersFromSalesOrderList() : Orders From SalesOrder : Error occurred while orders -> {}, error -> {}",
                        JsonMapper.fromObjectToJson(ordersResponse), e.getMessage(), e);
                summary.setFailed(true);
            }
            createSupportEmail(1, applicationProperties.getLimit(), "", OrdersResponse.class, "salesOrderItem", AppConstants.FAILED + " : Orders Response cannot be null");
            throw new ServiceException(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value(), "Error while converting the orders list");

        }
    }

    private void updateOrderWithLineItem(Orders orders, SalesOrder salesOrder, String currencySymbol,
                                         Map<String, List<Double>> ordersValueMap, Map<String, String> currencySymbolMap) {

        List<LineItems> lineItemsList = orders.getLineItems();
        boolean isUpdated = false;

        // First, check if there's an existing LineItems with a null invoiceNumber
        for (LineItems items : lineItemsList) {
            if (items.getInvoiceNumber() == null && salesOrder.getInvoiceNr() == null) {
                // Update the existing LineItems with null invoiceNumber
                //items.setInvoiceDate(salesOrder.getInvoiceDate());
                List<InvoiceNumberSpecificLineItems> invoiceNumberList = items.getInvoiceNumberSpecificLineItems();
                invoiceNumberList.add(getInvoiceNumberSpecificLineItems(salesOrder, currencySymbol, ordersValueMap, currencySymbolMap));
                isUpdated = true;
                break;  // Exit the loop as we've found and updated the entry
            }
        }

 // If no matching LineItems with null invoiceNumber was found, check for an existing LineItems with the same invoiceNumber
        if (!isUpdated) {
            for (LineItems items : lineItemsList) {
                if (items.getInvoiceNumber() != null && items.getInvoiceNumber().equals(salesOrder.getInvoiceNr())) {
                    // Update the existing LineItems with the matching invoiceNumber
                    List<InvoiceNumberSpecificLineItems> invoiceNumberList = items.getInvoiceNumberSpecificLineItems();
                    invoiceNumberList.add(getInvoiceNumberSpecificLineItems(salesOrder, currencySymbol, ordersValueMap, currencySymbolMap));
                    isUpdated = true;
                    break;  // Exit the loop as we've found and updated the entry
                }
            }
        }

        // If no matching LineItems with the same invoice number was found, create a new one
        if (!isUpdated) {
            LineItems newLineItem = new LineItems();
            newLineItem.setInvoiceDate(salesOrder.getInvoiceDate());
            newLineItem.setInvoiceNumber(salesOrder.getInvoiceNr());
            List<InvoiceNumberSpecificLineItems> invoiceNumberList = new ArrayList<>();
            invoiceNumberList.add(getInvoiceNumberSpecificLineItems(salesOrder, currencySymbol, ordersValueMap, currencySymbolMap));
            newLineItem.setInvoiceNumberSpecificLineItems(invoiceNumberList);

            lineItemsList.add(newLineItem);  // Add the new LineItems
        }
        orders.setLineItems(lineItemsList);
    }

    private Orders getOrdersFromSalesOrders(SalesOrder salesOrder, String currencySymbol,
                                            Map<String, List<Double>> ordersValueMap, Map<String, String> currencySymbolMap) {
        Orders order = new Orders();
        order.setSalesOrderDate(salesOrder.getSalesOrderDate());
        order.setSalesOrder(salesOrder.getPhilipsOrderNo());
        order.setPartnerPODate(salesOrder.getCustomerPODate());
        order.setPartnerPO(salesOrder.getCustomerPurchaseOrderNo());
        SoldToParty soldToParty = new SoldToParty();
        soldToParty.setName(salesOrder.getSoldToName());
        soldToParty.setPartnerNumber(salesOrder.getSoldToNo());
        order.setSoldToParty(soldToParty);
        order.setSalesOrderStatus(salesOrder.getOverallOrderStatus());
        order.setShippingAddress(salesOrder.getShippingAddress());
        order.setBillingAddress(salesOrder.getBillingAddress());
        order.setPayeeAddress(salesOrder.getPayeeAddress());
        List<LineItems> lineItemsList = new ArrayList<>();
        LineItems lineItems = new LineItems();
        lineItems.setInvoiceDate(salesOrder.getInvoiceDate());
        lineItems.setInvoiceNumber(salesOrder.getInvoiceNr());
        List<InvoiceNumberSpecificLineItems> invoiceNumberList = new ArrayList<>();
        invoiceNumberList.add(getInvoiceNumberSpecificLineItems(salesOrder, currencySymbol, ordersValueMap, currencySymbolMap));
        lineItems.setInvoiceNumberSpecificLineItems(invoiceNumberList);
        lineItemsList.add(lineItems);
        order.setLineItems(lineItemsList);
        if (log.isDebugEnabled()) {
            log.info("ordersList() :  lineItemsList -> {} ", lineItemsList);
        }

        return order;
    }

    private List<Orders> calculationOrderItems(List<Orders> ordersList, Map<String, List<Double>> ordersValueMap, Map<String, String> currencySymbolMap) {
        if (log.isDebugEnabled()) {
            log.info("calculationOrderItems :  value {}  ", ordersList);
            log.info("final currency symbol with Sold PartnerNo  {} ", currencySymbolMap);

        }

        List<Orders> orderList = new ArrayList<>();

        ordersList.forEach(orders -> {

            long count = orders.getLineItems().stream().mapToLong(
                    lineItem -> lineItem.getInvoiceNumberSpecificLineItems().size()).sum();

            log.info("log count per order: {} ", count);
            orders.setLineItemCountPerOrder(count);

            String partnerNo = orders.getSoldToParty().getPartnerNumber();
            String key = partnerNo + ", " + orders.getSalesOrder() + ", " + orders.getPartnerPO();

            List<Double> doubleList = ordersValueMap.get(key);
            if (log.isDebugEnabled()) {
                log.info("doubleList : Orders Value :{}", doubleList);
            }
            Double totalOrder = doubleList.stream()
                    .mapToDouble(Double::doubleValue)
                    .sum();

            DecimalFormat df = new DecimalFormat(AppConstants.DECIMAL_FORMAT);
            orders.setOrderValue(currencySymbolMap.get(key) + (totalOrder > AppConstants.ZERO ? df.format(totalOrder) : totalOrder));
            orderList.add(orders);
        });


        return orderList;
    }

    private static InvoiceNumberSpecificLineItems getInvoiceNumberSpecificLineItems(SalesOrder salesOrder, String countryBySymbol,
                                                                                 Map<String, List<Double>> ordersValueMap, Map<String, String> currencySymbolMap) {
        if (log.isDebugEnabled()) {
            log.info(" getInvoiceDateSpecificLineItems : processing the Invoice number Specific line items from sales Order data ");
        }
        InvoiceNumberSpecificLineItems invoiceNumberSpecificLineItems =
                new InvoiceNumberSpecificLineItems();
        invoiceNumberSpecificLineItems.setSalesOrderItemId(salesOrder.getSaleOrderItem());
        invoiceNumberSpecificLineItems.setMaterialNumber(salesOrder.getMaterial());
        invoiceNumberSpecificLineItems.setMaterialDescription(salesOrder.getDescription());
        invoiceNumberSpecificLineItems.setOverallOrderStatus(salesOrder.getOverallOrderStatus());
        invoiceNumberSpecificLineItems.setDeliveryType(salesOrder.getDeliveryType());
        invoiceNumberSpecificLineItems.setFactoryShipStatus(salesOrder.getFactoryShipStatus());
        invoiceNumberSpecificLineItems.setDeliveryNumber(salesOrder.getDeliveryNr());
        invoiceNumberSpecificLineItems.setInvoiceNumber(salesOrder.getInvoiceNr());
        invoiceNumberSpecificLineItems.setUnitPrice_OrderValue(salesOrder.getNetValueItem());
        invoiceNumberSpecificLineItems.setCurrencyOfValue(salesOrder.getCurrency());
        invoiceNumberSpecificLineItems.setFactoryShipDate(salesOrder.getFactoryShipDate());
        invoiceNumberSpecificLineItems.setRequiredDeliveryDate(salesOrder.getRequiredDeliveryDate());
        invoiceNumberSpecificLineItems.setCustomerGroupCode(salesOrder.getCustomer_Group_Code());
        invoiceNumberSpecificLineItems.setSalesDocType(salesOrder.getSalesDocType());
        invoiceNumberSpecificLineItems.setCustomerGroupDescription(salesOrder.getCustomerGroupDescription());
        invoiceNumberSpecificLineItems.setTotalPriceOfLineItem(getTotalPriceOfLineItemCalculate(salesOrder, countryBySymbol, ordersValueMap, currencySymbolMap));
        invoiceNumberSpecificLineItems.setQuantity(salesOrder.getQuantity());
        invoiceNumberSpecificLineItems.setUnitPrice_OrderValue(salesOrder.getNetValueItem());
        invoiceNumberSpecificLineItems.setTimeStamp(salesOrder.getTimeStamp());
        invoiceNumberSpecificLineItems.setEstimatedArrivalDateAtCustomer(salesOrder.getEstimatedArrivalDate());
        invoiceNumberSpecificLineItems.setPhilipsWarehouseShipDate(salesOrder.getPhilipsWarehouseShipDate());
        invoiceNumberSpecificLineItems.setWarehouseShipStatus(salesOrder.getWarehouseShipStatus());
        invoiceNumberSpecificLineItems.setEstimatedDateAtPhilipsWarehouse(salesOrder.getEstimateddate());
        invoiceNumberSpecificLineItems.setOrderStatus(salesOrder.getOrderStatus());
        invoiceNumberSpecificLineItems.setPhilipsWarehouseStatus(salesOrder.getPhilipsWarehouseStatus());
        invoiceNumberSpecificLineItems.setInvoiceDate(salesOrder.getInvoiceDate());
        return invoiceNumberSpecificLineItems;
    }


    private static String getTotalPriceOfLineItemCalculate(SalesOrder salesOrder, String currencySymbol,
                                                           Map<String, List<Double>> ordersValueMap, Map<String, String> currencySymbolMap) {

        String soldToNo = salesOrder.getSoldToNo();
        double netValueItem = Double.parseDouble(salesOrder.getNetValueItem());
        long quantity = salesOrder.getQuantity();
        String key = soldToNo + ", " + salesOrder.getPhilipsOrderNo() + ", " + salesOrder.getCustomerPurchaseOrderNo();
        currencySymbolMap.put(key, currencySymbol);

        double totalPrice = netValueItem > AppConstants.ZERO ? quantity * netValueItem : AppConstants.ZERO;
        DecimalFormat df = new DecimalFormat(AppConstants.DECIMAL_FORMAT);

        if (log.isDebugEnabled()) {
            log.info("OrderValue:{}", ordersValueMap);
        }
        List<Double> orderValues;

        if (ordersValueMap.containsKey(key)) {
            orderValues = ordersValueMap.get(key);

        } else {
            orderValues = new ArrayList<>();
        }
        orderValues.add(totalPrice);
        ordersValueMap.put(key, orderValues);

        return currencySymbol + (totalPrice > AppConstants.ZERO ? df.format(totalPrice) : totalPrice);
    }

    private static Map<String, String> countryCodeToCurrencySymbol() {
        Map<String, String> currencySymbolMap = new HashMap<>();
        Set<Currency> currencies = Currency.getAvailableCurrencies();

        for (Currency currency : currencies) {
            String code = currency.getCurrencyCode();
            Locale locale = findLocaleForCurrency(code);
            String symbol = currency.getSymbol(locale);
            // log.info("Country: " + currency.getDisplayName() + " | Currency code: " + code + " | Symbol: " + symbol);
            currencySymbolMap.put(code, symbol);
        }
        return currencySymbolMap;
    }


    private static Locale findLocaleForCurrency(String currencyCode) {
        for (Locale locale : Locale.getAvailableLocales()) {
            try {
                if (Currency.getInstance(locale).getCurrencyCode().equals(currencyCode)) {
                    return locale;
                }
            } catch (Exception e) {
                // throw new ServiceException(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value(), "Cannot Convert Currency formatting ");
            }
        }
        return Locale.US;
    }

    private Filter filterBuilder(String field, List<String> valuesList) {
        return Filter.builder().field(field)
                .values(valuesList)
                .operator(QueryOperator.IN)
                .build();
    }

    private void createSupportEmail(int page, int limit, String s, Class<?> c, String salesOrderItem, String message) {
        if (applicationProperties.isSummaryFlag()) {
            emailService.createSupportEmailAndSend(page, limit, s, c, salesOrderItem, message).subscribe();
            if (log.isInfoEnabled()) {
                log.info("createSupportEmail() : Email Sent has been Successful:  {}, {},{}", c, salesOrderItem, message);
            }
        }

    }

    private Filter filterBuilderValue(String field, String value, String value2) {
        List<String> valuesList = new ArrayList<>();
        valuesList.add(value);
        valuesList.add(value2);

        return Filter.builder().field(field)
                .values(valuesList)
                .operator(QueryOperator.NOT_EQ) //Date specified - between of two dates
                .build();
    }



}
