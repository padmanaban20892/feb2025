package com.philips.itaap.commercialit.css.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@Component
@SuppressWarnings("PMD.TooManyFields")
public class ApplicationProperties {

    @Value("${webclient.config.memory-buffer-size}")
    private int memoryBufferSize;

    @Value("${webclient.config.timeout}")
    private int timeout;

    @Value("${webclient.config.retry.maxretry}")
    private int maxRetry;

    @Value("${webclient.config.retry.delay}")
    private int delay;

    @Value("${email.endpoint}")
    private String emailUrl;

    @Value("${email.summary.flag}")
    private boolean summaryFlag;

    @Value("${email.summary.subject}")
    private String summarySubject;

    @Value("${email.summary.body}")
    private String summaryBody;

    @Value("${email.summary.recipients.to}")
    private List<String> recipientsTo;

    @Value("${email.summary.recipients.cc}")
    private List<String> recipientsSupportCc;

    @Value("${page.limit}")
    private int limit;

    @Value("${api.order.fetchOrders}")
    private String apiFetchOrdersDetails;

}
