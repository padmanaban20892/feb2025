package com.philips.itaap.commercialit.css.jpa.graphqlclient;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;


@Data
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
public class OrderServiceQueryResultList<T> extends QueryResultList<T> {

    /*public String getErrorMessage() {
        return !CollectionUtils.isEmpty(getErrors()) ?
                CPMUtils.getErrorMessage(getErrors())
                : getErrors().toString();
    }*/
}
