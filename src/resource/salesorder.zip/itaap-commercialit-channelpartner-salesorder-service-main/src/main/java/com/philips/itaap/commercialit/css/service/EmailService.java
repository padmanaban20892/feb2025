package com.philips.itaap.commercialit.css.service;

import brave.Tracer;
import brave.baggage.BaggageField;
import com.philips.itaap.commercialit.css.config.ApplicationProperties;
import com.philips.itaap.commercialit.css.constants.AppConstants;
import com.philips.itaap.commercialit.css.jpa.model.email.EmailRecord;
import com.philips.itaap.commercialit.css.jpa.model.email.EmailResponse;
import com.philips.itaap.commercialit.css.util.JsonMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.XSlf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.util.List;
import java.util.UUID;


/**
 * This class is used to send exception report.
 */
@Service
@XSlf4j
@RequiredArgsConstructor
public class EmailService {

    private final WebClient webClientEmail;
    private final ApplicationProperties properties;
    private final Retry attemptRetry;
    private final Tracer tracer;
    private final BaggageField correlationId;


    public Mono<EmailResponse> createSupportEmailAndSend(int page, int size, String filters, Class<?> c, String sortingRule, String message) {
        if (log.isInfoEnabled()) {
            log.info("createSupportEmailAndSend() : method invoked for email trigger flow -> {} ->{} ->{}", c.getSimpleName(), filters, sortingRule);
        }
        String subject = properties.getSummarySubject();
        String emailBody = properties.getSummaryBody();
        if (emailBody != null) {
            emailBody = emailBody
                    .replace(AppConstants.QUERY_NAME, c.getSimpleName())
                    .replace(AppConstants.CORRELATION_ID, !StringUtils.isEmpty(correlationId.getValue()) ? correlationId.getValue() : UUID.randomUUID().toString())
                    .replace(AppConstants.TRACER_ID, getTracerId())
                    .replace(AppConstants.PAGE_NO, String.valueOf(page))
                    .replace(AppConstants.PAGE_SIZE, String.valueOf(size))
                    .replace(AppConstants.FILTER, filters)
                    .replace(AppConstants.SORT_RULE, sortingRule)
                    .replace(AppConstants.EXCEPTION, message);
        }
        return sendEmail(getEmailRecord(subject, emailBody, properties.getRecipientsTo(), properties.getRecipientsSupportCc()));
    }

    public Mono<EmailResponse> sendEmail(EmailRecord emailRecord) {
        MultipartBodyBuilder bodyBuilder = new MultipartBodyBuilder();
        bodyBuilder.part(AppConstants.EMAIL_DATA, emailRecord);
        MultiValueMap<String, HttpEntity<?>> requestBody = bodyBuilder.build();
        return send(requestBody)
                .doOnSuccess(emailResponse -> {
                    if (log.isDebugEnabled()) {
                        log.debug("sendEmail() : Email Response -> {}", JsonMapper.fromObjectToJson(emailResponse));
                    }
                });
    }

    private Mono<EmailResponse> send(MultiValueMap<String, HttpEntity<?>> emailForm) {
        if (log.isDebugEnabled()) {
            log.debug("send() : emailForm -> {}", JsonMapper.fromObjectToJson(emailForm));
        }

        return webClientEmail
                .post()
                .uri(properties.getEmailUrl())
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(emailForm))
                .accept(MediaType.APPLICATION_JSON)
                .exchangeToMono(clientResponse -> {
                    if (clientResponse.statusCode().isError()) {
                        return clientResponse.bodyToMono(String.class)
                                .map(error -> {
                                    if (log.isErrorEnabled()) {
                                        log.error("send() : Exception Occurred {} from ITaaP Email Service. Response body -> {}", clientResponse.statusCode(), error);
                                    }
                                    EmailResponse email = new EmailResponse();
                                    email.setStatus(AppConstants.FAILED + " : " + error);
                                    return email;
                                });
                    } else {
                        return clientResponse.bodyToMono(EmailResponse.class).map(emailResponse -> {
                            if (log.isInfoEnabled()) {
                                log.info("send() : Email Sent Successfully");
                            }
                            return emailResponse;
                        });
                    }
                })
                .retryWhen(attemptRetry);
    }

    public static EmailRecord getEmailRecord(String subject, String emailBody, List<String> to, List<String> cc) {
        EmailRecord emailRecord = new EmailRecord();
        if (!CollectionUtils.isEmpty(to)) {
            emailRecord.setTo(to);
        }
        if (!CollectionUtils.isEmpty(cc)) {
            emailRecord.setCc(cc);
        }
        emailRecord.setSubject(subject);
        emailRecord.setPriority("1");
        emailRecord.setProjectName(AppConstants.EMAIL_PROJECT_NAME);
        emailRecord.setPlatformName(AppConstants.EMAIL_PLATFORM_NAME);
        emailRecord.setBody(emailBody);
        return emailRecord;
    }

    public String getTracerId() {
        if (tracer.currentSpan() != null) {
            return tracer.currentSpan().context().traceIdString();
        } else {
            return tracer.newTrace().context().traceIdString();
        }
    }
}



