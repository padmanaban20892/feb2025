package com.philips.itaap.commercialit.css.common;


import com.philips.itaap.commercialit.css.util.JsonMapper;
import com.philips.itaap.ms.dev.base.exception.ServiceException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.XSlf4j;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;
import com.philips.itaap.graphqlbase.common.Filter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

@XSlf4j
@AllArgsConstructor
@SuppressWarnings({"PMD.PreserveStackTrace", "CPD-START", "PMD.UnnecessaryFullyQualifiedName", "unchecked", "rawtypes", "cast", "PMD.SimpleDateFormatNeedsLocale"}) //SuppressWarnings: for a good reason.
public class CommonSpecifications<T> {

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
    public Specification<T> getSpecificationFromFilters(List<Filter> filter) {
        if (CollectionUtils.isEmpty(filter)) {
            if (log.isWarnEnabled()) {
                log.warn("getSpecificationFromFilters() : No filters provided");
            }
            return null;
        } else {
            Specification<T> specification = Specification.where(this.createSpecification((Filter) filter.remove(0)));

            Filter input;
            for (Iterator var3 = filter.iterator(); var3.hasNext(); specification = specification.and(this.createSpecification(input))) {
                input = (Filter) var3.next();
            }

            return specification;
        }
    }

    private Specification<T> createSpecification(Filter input) {

        try {
            switch (input.getOperator()) {
                case EQUALS:
                    return (root, query, criteriaBuilder) -> {
                        return criteriaBuilder.equal(root.get(input.getField()), this.castToRequiredType(root.get(input.getField()).getJavaType(), input.getValue()));
                    };
                case NOT_EQ: //use the Date Between , not works as NOT_EQ
                    return (root, query, criteriaBuilder) -> {
                        try {
                            Date startDate = dateFormat.parse(input.getValues().get(0).trim() + "T00:00:00");
                            Date endDate = dateFormat.parse(input.getValues().get(1).trim() + "T23:59:59");

                            return criteriaBuilder.between(
                                    root.get(input.getField()), startDate, endDate);
                        } catch (ParseException e) {
                            throw new IllegalArgumentException(" Date format issue");
                        }
                    };
                case GREATER_THAN:
                    return (root, query, criteriaBuilder) -> {
                        return criteriaBuilder.gt(root.get(input.getField()), (Number) this.castToRequiredType(root.get(input.getField()).getJavaType(), input.getValue()));
                    };
                case LESS_THAN:
                    return (root, query, criteriaBuilder) -> {
                        return criteriaBuilder.lt(root.get(input.getField()), (Number) this.castToRequiredType(root.get(input.getField()).getJavaType(), input.getValue()));
                    };
                case LIKE:
                    return (root, query, criteriaBuilder) -> {
                        return criteriaBuilder.like(root.get(input.getField()), "%" + input.getValue() + "%");
                    };
                case IN:
                    return (root, query, criteriaBuilder) -> {
                        return criteriaBuilder.in(root.get(input.getField())).value(this.castToRequiredType(root.get(input.getField()).getJavaType(), input.getValues()));
                    };
                default:
                    // throw new RuntimeException(ServiceErrors.UNSUPPORTED_OPERATION.newEx());
                    throw new ServiceException(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value(), "This operation is not supported");
            }
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("getSaleOrderByADL() : Exception occurred for create specification -> {} ERROR ->{}",
                        JsonMapper.fromObjectToJson(input), e.getLocalizedMessage(), e);
            }

            throw new ServiceException(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value(), "Error the converting the filter ");
        }
    }

    private Object castToRequiredType(Class fieldType, String value) {
        if (fieldType.isAssignableFrom(Double.class)) {
            return Double.valueOf(value);
        } else if (fieldType.isAssignableFrom(Integer.class)) {
            return Integer.valueOf(value);
        } else if (fieldType.isAssignableFrom(Boolean.class)) {
            return Boolean.valueOf(value);
        } else if (Enum.class.isAssignableFrom(fieldType)) {
            return Enum.valueOf(fieldType, value);
        } else {
            return String.class.isAssignableFrom(fieldType) ? value : null;
        }
    }

    private Object castToRequiredType(Class fieldType, List<String> value) {
        List<Object> lists = new ArrayList();
        Iterator var4 = value.iterator();

        while (var4.hasNext()) {
            String s = (String) var4.next();
            lists.add(this.castToRequiredType(fieldType, s));
        }

        return lists;
    }



}
