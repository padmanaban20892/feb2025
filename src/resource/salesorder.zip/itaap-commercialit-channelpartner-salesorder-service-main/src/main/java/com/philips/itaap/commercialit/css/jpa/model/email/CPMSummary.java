package com.philips.itaap.commercialit.css.jpa.model.email;

import com.philips.itaap.commercialit.css.constants.AppConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("PMD.TooManyFields")
@Builder
public class CPMSummary {

    /*
    @param something a String value
     */
    private String correlationId;
    private String sourceSystem;
    private String endpoint;
    private String startTime;
    private String flowName;
    private boolean failed;

    @Builder.Default
    private String operationDetails = "<tr><th colspan='4' style='text-align: center;'>" + AppConstants.SKIPPED + "</th></tr>";

    @Builder.Default
    private String userRegStatus = AppConstants.SKIPPED;

    @Builder.Default
    private String globalException = AppConstants.SKIPPED;
}