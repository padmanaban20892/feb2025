package com.philips.itaap.commercialit.css.service;

import com.philips.itaap.commercialit.css.common.CommonSpecifications;
import com.philips.itaap.commercialit.css.config.ApplicationProperties;
import com.philips.itaap.commercialit.css.constants.AppConstants;
import com.philips.itaap.commercialit.css.jpa.entity.SalesOrder;
import com.philips.itaap.commercialit.css.jpa.model.OrdersDto;
import com.philips.itaap.commercialit.css.jpa.model.PageInfo;
import com.philips.itaap.commercialit.css.jpa.model.SalesOrderConnection;
import com.philips.itaap.commercialit.css.jpa.repository.SalesOrderRepository;
import com.philips.itaap.commercialit.css.util.JsonMapper;
import com.philips.itaap.graphqlbase.common.DataAccessException;
import com.philips.itaap.graphqlbase.common.Filter;
import com.philips.itaap.graphqlbase.common.OLAPRepository;
import com.philips.itaap.graphqlbase.common.OLAPSpecifications;
import com.philips.itaap.graphqlbase.common.QueryOperator;
import com.philips.itaap.graphqlbase.common.SortingRule;
import com.philips.itaap.graphqlbase.service.QueryResolver;
import com.philips.itaap.ms.dev.base.exception.ServiceException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.XSlf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Date;
import java.util.Base64;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;



@Service
@XSlf4j
@RequiredArgsConstructor
@SuppressWarnings({"CPD-START", "unchecked", "PMD.UnnecessaryFullyQualifiedName", "PMD.ExcessiveImports", "PMD.SimpleDateFormatNeedsLocale"}) // SuppressWarnings: handling legacy code with raw types
public class DataFetcherService {
    private final ApplicationProperties applicationProperties;
    private final EmailService emailService;
    private final QueryResolver resolver;
    private final SalesOrderRepository salesOrderRepository;

    public <T, I> Flux<SalesOrderConnection> getPaginatedSalesOrders(int page, int size, String after, List<Filter> filterList, SortingRule sortingRule, OLAPRepository<T, I> olapRepository, Class<T> clazz) {
        List<Filter> logFilters = new ArrayList<>(CollectionUtils.isEmpty(filterList) ? Collections.emptyList() : filterList);
        try {
            PageInfo pageInfo;
            int pageNo = (page != 0) ? page - 1 : 0;
            String cursorId = after != null ? decodeCursor(after) : "";
            log.info("getPaginatedSalesOrders() : cursorId -> {}", cursorId);
            if (!cursorId.isEmpty()) {
                Filter filter = Filter.builder()
                        .field(cursorId.split(AppConstants.COLON)[0])
                        .value(cursorId.split(AppConstants.COLON)[1])
                        .operator(QueryOperator.GREATER_THAN)
                        .build();
                logFilters.add(filter);
            }

            Page<T> listPage = olapRepository.findAll(
                    new OLAPSpecifications<T>().getSpecificationFromFilters(filterList), buildPageRequest(pageNo, size, sortingRule));

            int totalPages = listPage.getTotalPages();
            List<SalesOrder> resultSet = resolver.search(pageNo, size, filterList, sortingRule, olapRepository);


            if (log.isInfoEnabled()) {
                log.info("getPaginatedSalesOrders : Total Value -> {}, Total Pages: {},  " +
                                " pageNo:{} , Result Size:{}",
                        listPage.getTotalElements(), totalPages, page, resultSet.size());
            }

            if (!CollectionUtils.isEmpty(resultSet)) {
                if (log.isInfoEnabled()) {
                    log.info("getPaginatedSalesOrders : Total Value -> {}, Total Page: {}, Result Size:{}", listPage.getTotalElements(), listPage.getTotalPages(), resultSet.size());
                }
                String endCursor = !resultSet.isEmpty() ? AppConstants.SALE_ORDER_ITEM + AppConstants.COLON  + resultSet.get(resultSet.size() - 1).getSaleOrderItem() : " ";

                pageInfo = PageInfo.builder()
                        .endCursor(encodeCursor(endCursor))
                        .hasNextPage(resultSet.size() == size)
                        .totalPageNo(listPage.getTotalPages())
                        .totalNumberOfRecords(listPage.getTotalElements())
                        .pageNo(page)
                        .build();
                log.info("getPaginatedSalesOrders() : PageInfo :  {}", pageInfo);
                return Flux.just(SalesOrderConnection.builder().pageInfo(pageInfo).salesOrders(resultSet).build());
            } else {

                return Flux.just(SalesOrderConnection.builder().pageInfo(new PageInfo()).salesOrders(new ArrayList<>(0)).build());
            }

        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("getPaginatedSalesOrders() : Exception occurred for page -> {}, size -> {}, filters -> {}, sortingRule -> {}, cursor -> {} , Error -> {}",
                        page, size, JsonMapper.fromObjectToJson(logFilters), sortingRule, after, e.getLocalizedMessage());
            }
            if (applicationProperties.isSummaryFlag()) {
                emailService.createSupportEmailAndSend(page, size, JsonMapper.fromObjectToJson(logFilters), clazz, JsonMapper.fromObjectToJson(sortingRule), AppConstants.FAILED + " : Sales Order Details cannot be null").subscribe();
                if (log.isInfoEnabled()) {
                    log.info("getPaginatedSalesOrders() : Email Sent has been Successful:  {}, {},{}", clazz, JsonMapper.fromObjectToJson(sortingRule), e.getLocalizedMessage());
                }
            }
            return Flux.error(new DataAccessException(AppConstants.UNABLE_TO_ACCESS_DATA));
        }
    }

    private Pageable buildPageRequest(int page, int size, SortingRule sortingRule) {
        PageRequest pageRequest;
        if (Objects.isNull(sortingRule)) {
            pageRequest = PageRequest.of(page, size);
        } else {
            pageRequest = PageRequest.of(page, size,
                    Sort.by(Sort.Direction.valueOf(sortingRule.getOrder()), sortingRule.getField()));
        }
        return pageRequest;
    }

    private String encodeCursor(String id) {
        return Base64.getEncoder().encodeToString(id.getBytes());
    }

    private String decodeCursor(String cursor) {
        return new String(Base64.getDecoder().decode(cursor));
    }


    private Boolean isAvailablePage(int resultSize, long totalCount, int pageSize, int totalPages, int page) {
        if (log.isInfoEnabled()) {
            log.info("checkNextPage : Total Value -> {}, Result Size:{}, pageSize: {},  totalPages : {}",
                    totalCount, resultSize, resultSize, totalPages);
        }
        return  resultSize == pageSize && totalPages != page;
    }

    public Pageable pageRequest(int page, int size, String sort) {
        PageRequest pageRequest;

            pageRequest = PageRequest.of(page, size,
                    Sort.by(sort));

        return pageRequest;
    }

    public Pageable pageRequestWithNativeQuery(int page, int size) {
        PageRequest pageRequest;

        pageRequest = PageRequest.of(page, size
                , Sort.by(AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));

        return pageRequest;
    }

    public <T, I> Mono<SalesOrderConnection> getSaleOrderByADLWithNativeQuery(int page, int size,
                                                                              List<Filter> filterList,
                                                                              OLAPRepository<T, I> olapRepository,
                                                                              Class<T> clazz, OrdersDto orderDto) {
        List<Filter> lineDataFilter = new ArrayList<>();
        List<Filter> logFilters = new ArrayList<>(CollectionUtils.isEmpty(filterList) ? Collections.emptyList() : filterList);
        PageInfo pageInfo;
        Page<String> orderPage;
        try {

            if (log.isInfoEnabled()) {
                log.info("getSaleOrderByADLWithNativeQuery() :  Received the data from order api - page -> {}, size -> {}, filters -> {}",
                        page, size, JsonMapper.fromObjectToJson(logFilters));

            }
            int pageNo = page != 0 ? page - 1 : 0;
            String logMessage;
            if (CollectionUtils.isEmpty(logFilters)) {
                logMessage = " getSaleOrderByADLWithNativeQuery() : No filter  ";
                orderPage = salesOrderRepository.findDistinctPhilipsOrderNumberBySalesOrderNumber(pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
            } else {
                logMessage = " getSaleOrderByADLWithNativeQuery() : filter";
                orderPage = findDistinctPhilipsOrderNoNativeQuery(orderDto, pageNo, size);
            }

            if (orderPage != null &&  orderPage.getTotalElements() > 0) {
                List<String> ordersResult = orderPage.getContent();
                if (log.isInfoEnabled()) {
                    log.info(logMessage);
                    log.info("getSaleOrderByADLWithNativeQuery : Total Value -> {}, Total Pages: {},  " +
                                    " pageNo : {} , Result Size : {}, Result set :{}",
                            orderPage.getTotalElements(), orderPage.getTotalPages(), page, ordersResult.size(), ordersResult);
                }
                lineDataFilter.add(Filter.builder()
                        .field(AppConstants.PHILIPSORDERNO)
                        .values(ordersResult)
                        .operator(QueryOperator.IN)
                        .build());

                List<SalesOrder> resultSet = (List<SalesOrder>) olapRepository.findAll(
                        new CommonSpecifications<T>().getSpecificationFromFilters(lineDataFilter));

                int totalPages = orderPage.getTotalPages();
                int resultSize = ordersResult.size();
                long totalCount = orderPage.getTotalElements();
                if (log.isInfoEnabled()) {
                    log.info("getSaleOrderByADLWithNativeQuery  Order_data : Total Value -> {}, Total Pages: {},  " +
                                    " pageNo : {} , Result Size : {} , hasMoreItems -> {}, Line_data : Total count -> {}",
                            totalCount, totalPages, page, resultSize, resultSize == size, resultSet.size());
                }
                // if (!CollectionUtils.isEmpty(resultSet)) {
                pageInfo = PageInfo.builder()
                        .hasNextPage(isAvailablePage(resultSize, totalCount, size, totalPages, page))
                        .totalPageNo(totalPages)
                        .totalNumberOfRecords(page == 1 ? totalCount : null) //discussed with shilpa & Rajendra - if page is 1, send as total count otherwise is null
                        .pageNo(page)
                        .build();

                SalesOrderConnection salesOrderConnection = SalesOrderConnection.builder()
                        .pageInfo(pageInfo)
                        .salesOrders(resultSet)
                        .build();

                if (log.isDebugEnabled()) {
                    log.info(" getSaleOrderByADLWithNativeQuery() :  Data received successful from ADL service {}", salesOrderConnection);
                }
                return Mono.just(salesOrderConnection);
            } else {
                if (log.isInfoEnabled()) {
                    log.info(" getSaleOrderByADLWithNativeQuery() :  No order details received from ADL service ");
                }
                return Mono.just(SalesOrderConnection.builder()
                        .pageInfo(new PageInfo()).salesOrders(new ArrayList<>(0)).build());
            }

        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("getSaleOrderByADLWithNativeQuery() : Exception occurred ADL data for page -> {}, size -> {}, filters -> {}, sortingRule -> {},  Error -> {}",
                        page, size, JsonMapper.fromObjectToJson(logFilters), AppConstants.PHILIPSORDERNO, e.getLocalizedMessage(), e);
            }
            if (applicationProperties.isSummaryFlag()) {
                emailService.createSupportEmailAndSend(page, size, JsonMapper.fromObjectToJson(logFilters), clazz,  AppConstants.PHILIPSORDERNO, AppConstants.FAILED + " : Sales Order Details cannot be null from ADL").subscribe();
                if (log.isInfoEnabled()) {
                    log.info("getSaleOrderByADLWithNativeQuery() : Email Sent has been Successful:  {}, {},{}", clazz,  AppConstants.PHILIPSORDERNO, e.getLocalizedMessage());
                }
            }
            return Mono.error(new ServiceException(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value(), AppConstants.UNABLE_TO_ACCESS_DATA));
        }
    }

    public void getTotalNumberOfRecords(SalesOrderRepository salesOrderRepository) { //testing purpose

        List<Filter> filterLists = new ArrayList<>();
        List<String> s = new ArrayList<>();
        s.add("0000551306");

        filterLists.add(Filter.builder().field("soldToNo")
                .values(s)
                .operator(QueryOperator.IN)
                .build());
        try {
            Specification<SalesOrder> specification = new CommonSpecifications<SalesOrder>().getSpecificationFromFilters(filterLists);


            // Create a dynamic query to select distinct PhilipsOrderNo
            Page<String> orderPage = salesOrderRepository.findAll((root, query, criteriaBuilder) -> {
                /*//Root<SalesOrder> root = query.from(SalesOrder.class);

                // query.distinct(true);  // Ensure distinct PhilipsOrderNo*/
                query.select(root.get("philipsOrderNo")).distinct(true);  // Select PhilipsOrderNo only

                //query.where(specification.toPredicate(root, query, criteriaBuilder));

                // TypedQuery<String> typedQuery = entityManager.createQuery(query).getResultList();
                // Apply dynamic specifications
                return specification.toPredicate(root, query, criteriaBuilder);
            }, pageRequestWithNativeQuery(0, 15)).map(lineData -> lineData.getPhilipsOrderNo());

            List<String> ordersResult = orderPage.getContent();
            if (log.isInfoEnabled()) {
                log.info("getTotalNumberOfRecords : Total Value -> {}, Total Pages: {},  " +
                                " pageNo : {} , Result Size : {}",
                        orderPage.getTotalElements(), orderPage.getTotalPages(), 1, ordersResult);
            }
            //  return orderPage;
            // Map to PhilipsOrderNo
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("getTotalNumberOfRecords() : Exception occurred ADL data for Error -> {}",
                       e.getLocalizedMessage(), e);
            }
            // return null;
        }


    }

    public Page<String> findDistinctPhilipsOrderNoNativeQuery(OrdersDto orderDto, int pageNo, int size) throws ParseException {

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");

        List<String> soldToNo = orderDto.getParameters().getSoldToPartnerNumber();
        List<String> partnerPO = orderDto.getParameters().getPartnerPO();
        List<String> philipsOrderNo = orderDto.getParameters().getSalesOrder();

        Date startDate = orderDto.getParameters().getStartDate() != null ?
                dateFormat.parse(orderDto.getParameters().getStartDate().trim() + "T00:00:00") : null;
        Date endDate = orderDto.getParameters().getEndDate() != null ?
                dateFormat.parse(orderDto.getParameters().getEndDate().trim() + "T00:00:00") : null;

        if (log.isInfoEnabled()) {
            log.info("findDistinctPhilipsOrderNoNativeQuery : soldToNo -> {}, CustomerPurchaseOrderNo: {},  " +
                            " philipsOrderNo : {} ,startDate : {}, endDate :{}",
                    soldToNo, partnerPO, philipsOrderNo, startDate, endDate);
        }

        Page<String> orderPage = null;

        if (soldToNo != null && partnerPO == null && philipsOrderNo == null && startDate == null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoBySoldToNo(soldToNo, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo == null && partnerPO == null && philipsOrderNo != null && startDate == null)  {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoByPhilipsOrderNo(philipsOrderNo, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo == null && partnerPO != null && philipsOrderNo == null && startDate == null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoByCustomerPurchaseOrderNo(partnerPO, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }


        if (soldToNo != null && partnerPO != null && philipsOrderNo == null && startDate == null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoByCustomerPurchaseOrderNoSoldToNo(partnerPO, soldToNo,  pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo != null && partnerPO == null && philipsOrderNo != null && startDate == null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoByPhilipsOrderNoSoldToNo(philipsOrderNo, soldToNo, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo == null && partnerPO != null && philipsOrderNo != null && startDate == null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoByPhilipsOrderNoCustomerPurchaseOrderNo(philipsOrderNo, partnerPO, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }


        if (soldToNo != null && partnerPO != null && philipsOrderNo != null && startDate == null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrdNoByAllWithoutDate(partnerPO, soldToNo,  philipsOrderNo, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo != null && partnerPO == null && philipsOrderNo == null && endDate != null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoBySoldToNoWithDate(soldToNo,
                    startDate, endDate, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo == null && partnerPO == null && philipsOrderNo != null && endDate != null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoByPhilipsOrdNoWithDate(philipsOrderNo,
                    startDate, endDate, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo == null && partnerPO != null && philipsOrderNo == null && startDate != null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoByCustomerPurchaseOrderNoWithDate(partnerPO,
                    startDate, endDate, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo == null && partnerPO == null && philipsOrderNo == null && startDate != null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoBySalesOrderDate(startDate,
                    endDate, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo != null && partnerPO == null && philipsOrderNo != null && startDate != null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoByPhilipsOrderNoSoldToNoSODate(philipsOrderNo, soldToNo, startDate,
                    endDate, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo != null && partnerPO != null && philipsOrderNo == null && startDate != null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoByCustomerPurchaseOrderNoSoldToNoSODate(partnerPO, soldToNo, startDate,
                    endDate, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo == null && partnerPO != null && philipsOrderNo != null && startDate != null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrderNoByPhilipsOrderNoCustomerPurchaseOrderNoSODate(philipsOrderNo, partnerPO,
                    startDate, endDate, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }

        if (soldToNo != null && partnerPO != null && philipsOrderNo != null && startDate != null) {
            orderPage = salesOrderRepository.findDistinctPhilipsOrdNoByAll(soldToNo, partnerPO, philipsOrderNo,
                    startDate, endDate, pageRequest(pageNo, size, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY));
        }
        if (log.isInfoEnabled()) {
            log.info("findDistinctPhilipsOrderNoNativeQuery : Total Value -> {}, Total Pages: {},  " +
                            " pageNo : {} , Result Size : {}, Result set :{}",
                    orderPage.getTotalElements(), orderPage.getTotalPages(), pageNo, orderPage.isEmpty(), orderPage);
        }

        return orderPage;


    }


}