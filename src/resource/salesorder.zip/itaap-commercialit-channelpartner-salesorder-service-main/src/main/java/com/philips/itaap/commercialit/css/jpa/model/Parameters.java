package com.philips.itaap.commercialit.css.jpa.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Parameters {


    @JsonProperty("PartnerPO")
    public List<String> partnerPO; //Customer Purchase Order Number [customerPurchaseOrderNo]

    @JsonProperty("SoldToPartnerNumber")
    public List<String> soldToPartnerNumber; // Sold to number [soldToNo]
    @JsonProperty("SalesOrder")
    public List<String> salesOrder; //Philips Order Number [philipsOrderNo]

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "s")
    @JsonProperty("StartDate")
    public String startDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "s")
    @JsonProperty("EndDate")
    public String endDate;

    @JsonProperty("OffSet")
    public int offSet;

}
