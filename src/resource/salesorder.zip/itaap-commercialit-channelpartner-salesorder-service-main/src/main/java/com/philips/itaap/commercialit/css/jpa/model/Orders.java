package com.philips.itaap.commercialit.css.jpa.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.philips.itaap.commercialit.css.constants.AppConstants;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@SuppressWarnings("PMD.TooManyFields")
public class Orders implements Serializable {

    private static final long serialVersionUID = 3876760426857369364L;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = AppConstants.DATE_PATTERN)
    private String partnerPODate;

   @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = AppConstants.DATE_PATTERN)
    private Date salesOrderDate;

    private String partnerPO;

    private String salesOrder;

    private String salesOrderStatus;

    private SoldToParty soldToParty;

    private String shippingAddress;

    private String billingAddress;

    private String payeeAddress;

    private String orderValue;

    private long lineItemCountPerOrder;

    private List<LineItems> lineItems;


}
