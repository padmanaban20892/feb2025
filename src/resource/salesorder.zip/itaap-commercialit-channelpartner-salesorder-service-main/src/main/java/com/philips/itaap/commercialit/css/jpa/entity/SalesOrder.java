package com.philips.itaap.commercialit.css.jpa.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.philips.itaap.commercialit.css.constants.AppConstants;
import com.philips.itaap.commercialit.css.jpa.compositekey.SalesOrderKey;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Column;
import java.io.Serializable;
import java.util.Date;


@Data
@Entity
@Table(name = AppConstants.SALE_ORDER_DATA, schema = AppConstants.SALE_ORDER_DATA)
@IdClass(SalesOrderKey.class)
@SuppressWarnings("PMD.TooManyFields")
public class SalesOrder implements Serializable {

 private static final long serialVersionUID = -5843073699720732977L;

 @Id
 @Column(name = "Sold_To_Number")
 private String   soldToNo;

 @Column(name = "Sold_To_Name")
 private String   soldToName;

 @Column(name = "Customer_PO_Date")
 private String   customerPODate;

 @Id
 @Column(name = "Customer_Purchase_Order_Number")
 private String   customerPurchaseOrderNo;

 @Id
 @Column(name = "Philips_Order_Number")
 private String   philipsOrderNo;

 @Id
 @Column(name = "Sales_Order_Item")
 private String   saleOrderItem;

 @Column(name = "Material")
 private String   material;

 @Column(name = "Description")
 private String   description;
 @Column(name = "Quantity")
 private long   quantity;
 @Column(name = "Order_Status")
 private String   overallOrderStatus;
 @Column(name = "Delivery_Type")
 private String   deliveryType;
 @Column(name = "Factory_Ship_Status")
 private String   factoryShipStatus;
 @Column(name = "Philips_Warehouse_Status")
 private String   philipsWarehouseStatus;
 @Column(name = "Delivery_Nr")
 private String   deliveryNr;
 @Column(name = "Invoice_Nr")
 private String   invoiceNr;
 @Column(name = "Invoice_Date")
 private String invoiceDate;
 @Column(name = "Net_Value_Item")
 private String   netValueItem;
 @Column(name = "Currency")
 private String   currency;
 @Column(name = "Factory_Ship_Date")
 private String   factoryShipDate;
 @Column(name = "Required_Delivery_Date")
 private String   requiredDeliveryDate;
 @Column(name = "Customer_Group_Code")
 private String   customer_Group_Code;
 @Column(name = "Sales_Doc_Type")
 private String   salesDocType;
 @Column(name = "CustomerGroup_description")
 private String   customerGroupDescription;
 @Column(name = "orderstatus")
 private String   orderStatus;
 @Column(name = "Shipping_Address")
 private String   shippingAddress;
 @Column(name = "Billing_Address")
 private String   billingAddress;
 @Column(name = "Payee_Address")
 private String   payeeAddress;
 @Column(name = "timeStamp")
 @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
 private Date timeStamp;
 @Column(name = "Estimated_Date_At_Philips_Warehouse")
 private String estimateddate;
 @Column(name = "Warehouse_Ship_Status")
 private String   warehouseShipStatus;
 @Column(name = "Philips_Warehouse_Ship_Date")
 private String   philipsWarehouseShipDate;
 @Column(name = "Estimated_Arrival_Date_At_Customer")
 private String   estimatedArrivalDate;
 //estimated Arrival Date at Customer
 @Column(name = "SalesOrder_Date")
 private Date salesOrderDate;

}