package com.philips.itaap.commercialit.css.jpa.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.philips.itaap.commercialit.css.constants.AppConstants;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
@SuppressWarnings("PMD.TooManyFields")
public class InvoiceNumberSpecificLineItems implements Serializable {


    private static final long serialVersionUID = -826077251477581421L;

    private String salesOrderItemId;

    private String materialNumber;

    private String materialDescription;

    private long quantity;

    private String overallOrderStatus;

    private String deliveryType;

    private String factoryShipStatus;

    private String philipsWarehouseStatus;

    private String deliveryNumber;

    private String invoiceNumber;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = AppConstants.DATE_PATTERN)
    private String invoiceDate;

    private String unitPrice_OrderValue;

    private String currencyOfValue;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = AppConstants.DATE_PATTERN)
    private String factoryShipDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = AppConstants.DATE_PATTERN)
    private String requiredDeliveryDate;

    private String customerGroupCode;

    private String salesDocType;

    private String customerGroupDescription;

    private String orderStatus;

    private String estimatedDateAtPhilipsWarehouse;

    private String warehouseShipStatus;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = AppConstants.DATE_PATTERN)
    private String philipsWarehouseShipDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = AppConstants.DATE_PATTERN)
    private String estimatedArrivalDateAtCustomer;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private Date timeStamp;

    private String totalPriceOfLineItem;



}
