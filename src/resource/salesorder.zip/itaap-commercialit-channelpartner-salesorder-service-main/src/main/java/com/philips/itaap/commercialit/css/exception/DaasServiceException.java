package com.philips.itaap.commercialit.css.exception;

public class DaasServiceException extends RuntimeException {

    private static final long serialVersionUID = -2191022654377788456L;

    public DaasServiceException(String message) {
        super(message);
    }
}
