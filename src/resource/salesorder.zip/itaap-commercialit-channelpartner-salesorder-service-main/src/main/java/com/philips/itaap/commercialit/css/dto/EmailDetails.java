package com.philips.itaap.commercialit.css.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmailDetails {

    @JsonProperty("to")
    public List<String> to;

    @JsonProperty("cc")
    public List<String> cc;

    @JsonProperty("subject")
    public String subject;

    @JsonProperty("body")
    public String body;

}

