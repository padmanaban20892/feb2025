package com.philips.itaap.commercialit.css.client;

import com.philips.itaap.commercialit.css.service.OrderServiceTokenService;
import com.philips.itaap.commercialit.css.jpa.graphqlclient.OrderServiceQueryResult;
import com.philips.itaap.commercialit.css.jpa.graphqlclient.OrderServiceQueryResultList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.graphql.client.HttpGraphQlClient;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Map;

@Slf4j
@Service
@SuppressWarnings({"CPD-START"})
public class OrderServiceGraphQlClient extends GraphqlClient {
    private final OrderServiceTokenService orderServiceTokenService;

    protected OrderServiceGraphQlClient(@Value("${order-service.graphql.endpoint}") String url,
                                        HttpGraphQlClient orderServiceHttpGraphQlClient,
                                        OrderServiceTokenService orderServiceTokenService) {
        super(orderServiceHttpGraphQlClient, url);
        this.orderServiceTokenService = orderServiceTokenService;

    }

    public <T> Mono<OrderServiceQueryResult<T>> getGraphQLQueryResultByDocumentName(String documentName, String path, Map<String, Object> variables,
                                                                                    ParameterizedTypeReference<T> entityType) {
        if (log.isInfoEnabled()) {
            log.info("getGraphQLQueryResultByDocumentName() -> documentName : {} path : {} variables : {}", documentName, path, variables);
        }
        return getQueryResultByDocumentName(Map.of(), documentName, path, variables, entityType)
                .onErrorResume(throwable -> {
                    if (log.isErrorEnabled()) {
                        log.error("getGraphQLQueryResultByDocumentName() : Error Occurred while calling order sevice . -> documentName : {} path : {} variables : {} Error -> {}",
                                documentName, path, variables, throwable.getMessage());
                    }
                    return Mono.just(OrderServiceQueryResult.<T>builder()
                            .failed(true)
                            .message(throwable.getMessage())
                            .build());
                })
                .map(queryResult -> OrderServiceQueryResult.<T>builder()
                        .failed(queryResult.isFailed())
                        .message(queryResult.getMessage())
                        .errors(queryResult.getErrors())
                        .data(queryResult.getData())
                        .build());
    }
    public <T> Mono<OrderServiceQueryResultList<T>> getGraphQLQueryResultListByDocumentName(String documentName, String path, Map<String, Object> variables,
                                                                                            ParameterizedTypeReference<T> entityType) {
        if (log.isInfoEnabled()) {
            log.info("getGraphQLQueryResultListByDocumentName() -> documentName : {} path : {} variables : {}", documentName, path, variables);
        }
        return orderServiceTokenService.getOrderServiceToken().flatMap(tokenData -> {
            if (tokenData.isFailed()) {
                if (log.isInfoEnabled()) {
                    log.info("getGraphQLQueryResultByDocumentName() -> token call is failed");
                }
                return Mono.just(OrderServiceQueryResultList.<T>builder()
                        .failed(tokenData.isFailed())
                        .message(tokenData.getMessage())
                        .build());
            }
            Map<String, String> headers = Map.of("Authorization", "Bearer " + tokenData.getAccessToken());

            return getQueryResultListByDocumentName(headers, documentName, path, variables, entityType).onErrorResume(throwable -> {
                        if (log.isErrorEnabled()) {
                            log.error("getGraphQLQueryResultByDocumentName() : Error Occurred while calling order sevice. -> documentName : {} path : {} variables : {} Error -> {}",
                                    documentName, path, variables, throwable.getMessage());
                        }
                        return Mono.just(OrderServiceQueryResultList.<T>builder()
                                .failed(true)
                                .message(throwable.getMessage())
                                .build());
                    })
                    .map(queryResult -> OrderServiceQueryResultList.<T>builder()
                            .failed(queryResult.isFailed())
                            .message(queryResult.getMessage())
                            .errors(queryResult.getErrors())
                            .data(queryResult.getData())
                            .build());
        });
    }
}
