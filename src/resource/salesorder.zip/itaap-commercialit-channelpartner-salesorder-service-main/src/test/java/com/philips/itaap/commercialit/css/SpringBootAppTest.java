/*
package com.philips.itaap.commercialit.css;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
*/
/*import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;

@ActiveProfiles("test")
@ContextConfiguration(classes = SpringBootApp.class)
@EnableJpaRepositories(basePackages = {"springbootapp.com.philips.itaap"})*//*

@SpringBootTest
public class SpringBootAppTest {
	@Test
	void contextLoads() {
	}
}
*/
