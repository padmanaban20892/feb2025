/*

package com.philips.itaap.commercialit.css.datafecher;


import com.philips.itaap.commercialit.css.config.ApplicationProperties;
import com.philips.itaap.commercialit.css.controller.OrderController;
import com.philips.itaap.commercialit.css.jpa.model.OrdersDto;
import com.philips.itaap.commercialit.css.jpa.model.OrdersResponse;
import com.philips.itaap.commercialit.css.service.OrderService;
import com.philips.itaap.commercialit.css.utils.TestUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


@ActiveProfiles("test")
@WebFluxTest(controllers = OrderController.class)
public class OrderControllerTest extends TestUtils {

    public static final String ORDER_SALES = "/orders";
    @Autowired
    OrderController orderController;
    @MockBean
    ApplicationProperties applicationProperties;

    @MockBean
    OrderService orderService;


    @Test
    void orderDetailsTest() throws IOException {

        OrdersDto ordersDto = getMockObject("model/orderDto.json", OrdersDto.class);
        OrdersResponse ordersResponse = getMockObject("model/orderResponse.json", OrdersResponse.class);
        List<OrdersResponse> ordersResponseList = new ArrayList<>();
        ordersResponseList.add(ordersResponse);

        Mockito.when(applicationProperties.getApiFetchOrdersDetails()).thenReturn(ORDER_SALES);
        Mockito.when(orderService.ordersDetail(ordersDto, applicationProperties.getApiFetchOrdersDetails()))
                .thenReturn(Flux.just(ordersResponse));

        Flux<OrdersResponse> response = orderController.ordersDetail(ordersDto);
       //StepVerifier.create(response).consumeNextWith(Assertions::assertNotNull).verifyComplete();
    }

}
*/
