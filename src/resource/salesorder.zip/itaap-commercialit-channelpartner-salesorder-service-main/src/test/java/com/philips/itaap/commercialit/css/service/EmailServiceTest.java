/*
package com.philips.itaap.commercialit.css.service;


import com.philips.itaap.commercialit.css.config.ApplicationProperties;
import com.philips.itaap.commercialit.css.constants.AppConstants;
import com.philips.itaap.commercialit.css.dto.EmailDetails;
import com.philips.itaap.graphqlbase.configuration.GraphqlbaseConfig;


import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.TraceContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;


@ActiveProfiles("test")
@SpringBootTest
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class, GraphqlbaseConfig.class})
public class EmailServiceTest {

    @Autowired
    EmailService emailService;

    @MockBean
    ApplicationProperties emailProperties;


    @Mock
    private WebClient webClient;

    @Mock
    WebClient.RequestBodyUriSpec requestBodyUriMock;

    @Mock
    WebClient.RequestHeadersSpec requestHeadersMock;

    @Mock
    WebClient.RequestBodySpec requestBodyMock;

    @Mock
    WebClient.ResponseSpec responseMock;


    @Mock
    private org.springframework.cloud.sleuth.Tracer tracer;
    @Mock
    private Span span;
    @Mock
    private TraceContext context;

    @Test
    public void testSendEmail() {
        mockTraceId();
        EmailDetails emailDetails = new EmailDetails();
        //   EmailResponse expectedResponse = new EmailResponse();

        List<String> email = new ArrayList<>();
        email.add("partner.padmanaban.a@philips.com");


        Mockito.when(emailProperties.getSummarySubject()).thenReturn("testing mail for salesOrder service");
        Mockito.when(emailProperties.getRecipientsTo()).thenReturn(email);
        Mockito.when(emailProperties.getRecipientsSupportCc()).thenReturn(email);
        Mockito.when(emailProperties.getSummaryBody()).thenReturn("Unit Test");
        // Mockito.when(emailProperties.get).thenReturn("Test");
        // Mockito.when(emailProperties.getPassword()).thenReturn("ea06fac51b0666");

        Mockito.when(AppConstants.CORRELATION_ID).thenReturn(UUID.randomUUID().toString());
        Mockito.when(AppConstants.TRACER_ID).thenReturn(UUID.randomUUID().toString());
        Mockito.when(AppConstants.PAGE_NO).thenReturn("1");
        Mockito.when(AppConstants.PAGE_SIZE).thenReturn("2");
        Mockito.when(AppConstants.FILTER).thenReturn("Unit Test");
        Mockito.when(AppConstants.SORT_RULE).thenReturn("IN");
        Mockito.when(AppConstants.EXCEPTION).thenReturn("Unit Test");
        //Mockito.when(tracer.currentSpan()).thenReturn(Span.class);


        when(emailProperties.getEmailUrl()).thenReturn("https://test-email-url.com");
        when(webClient.post()).thenReturn(requestBodyUriMock);

        when(requestBodyUriMock.uri(anyString())).thenReturn(requestBodyMock);


        when(requestHeadersMock.accept(any())).thenReturn(requestHeadersMock);

        when(requestBodyMock.contentType(any())).thenReturn(requestBodyMock);
        when(requestBodyMock.body(any())).thenReturn(requestHeadersMock);
        when(requestHeadersMock.exchangeToMono(any())).thenReturn(Mono.just(anyString()));

        emailService.createSupportEmailAndSend(0, 5, "test mail", EmailServiceTest.class, "test desc", "Invalid test");
        // emailService.sendEmail(0, 10, StringUtils.EMPTY, SalesOrder.class, StringUtils.EMPTY, "Invalid Page number");
    }

    private void mockTraceId() {
        Mockito.when(tracer.currentSpan()).thenReturn(span);
        Mockito.when(span.context()).thenReturn(context);
        Mockito.when(context.traceId()).thenReturn("a9d18095-3c52-45f2-b622-223d9da55a31");
    }
}

*/
