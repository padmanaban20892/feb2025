package com.philips.itaap.commercialit.css.jpa.entity;

import com.philips.itaap.commercialit.css.jpa.model.Data;
import com.philips.itaap.commercialit.css.jpa.model.MyP4P;
import com.philips.itaap.commercialit.css.utils.TestUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DataTest extends TestUtils {

    @Test
    void hashCodeTestScenario() throws IOException {
        Data data = test();
        Data data2 = test();
        assertEquals(data.hashCode(), data2.hashCode());
    }

    @Test
    void equalsTestDataScenario() throws IOException {
        Data data = test();
        Data data2 = test();
        boolean result = data.equals(data2);
        assertTrue(result);
    }

    void toString2Test() throws IOException {
        Data data = test();
        Data data2 = test();
        assertEquals(data.toString(), data2.toString());

    }

     public Data test() throws IOException {
        return getMockObject("./entity/data.json", Data.class);
    }

    @Test
    void hashCodeTestScenarioMyP4P() throws IOException {
        MyP4P myP4P = testMyP4P();
        MyP4P myP4P2 = testMyP4P();
        assertEquals(myP4P.hashCode(), myP4P2.hashCode());
    }

    public MyP4P testMyP4P() throws IOException {
        return getMockObject("./entity/myp4p.json", MyP4P.class);
    }


    @Test
    void toStringTest() throws IOException {
        MyP4P myP4P = testMyP4P();
        MyP4P myP4P2 = testMyP4P();
        assertEquals(myP4P.toString(), myP4P2.toString());

    }


}
