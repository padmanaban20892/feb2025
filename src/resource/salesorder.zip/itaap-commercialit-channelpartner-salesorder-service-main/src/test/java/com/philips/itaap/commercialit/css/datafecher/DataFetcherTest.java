/*

package com.philips.itaap.commercialit.css.datafecher;


import com.fasterxml.jackson.core.type.TypeReference;
import com.philips.itaap.commercialit.css.SpringBootApp;
import com.philips.itaap.commercialit.css.config.EntityMetaDataConfig;
import com.philips.itaap.commercialit.css.controller.DataFetcher;
import com.philips.itaap.commercialit.css.dto.ADLEntity;
import com.philips.itaap.commercialit.css.dto.EntityMetaData;
import com.philips.itaap.commercialit.css.jpa.entity.SalesOrder;
import com.philips.itaap.commercialit.css.jpa.repository.SalesOrderRepository;
import com.philips.itaap.commercialit.css.model.GraphQLQueryResponse;
import com.philips.itaap.commercialit.css.service.DataFetcherService;
import com.philips.itaap.commercialit.css.util.JwtGenerator;
import com.philips.itaap.commercialit.css.utils.TestUtils;
import com.philips.itaap.graphqlbase.service.QueryResolver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.graphql.security.GraphQlWebFluxSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.autoconfigure.security.reactive.ReactiveSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.graphql.GraphQlTest;
import org.springframework.boot.test.autoconfigure.graphql.tester.AutoConfigureGraphQlTester;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.core.io.ClassPathResource;
import org.springframework.graphql.test.tester.GraphQlTester;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;


import java.io.IOException;
import java.util.*;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ActiveProfiles("test")
@GraphQlTest
@SpringBootTest(classes = SpringBootApp.class)
@AutoConfigureGraphQlTester
@EnableAutoConfiguration(exclude = {HibernateJpaAutoConfiguration.class, DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class, GraphQlWebFluxSecurityAutoConfiguration.class, SecurityAutoConfiguration.class, ReactiveSecurityAutoConfiguration.class})
public class DataFetcherTest extends TestUtils {



    @MockBean
    QueryResolver queryResolver;
  */
/*  @MockBean
    SalesOrderRepository saleOrderRepository;
*//*

    @MockBean
    EntityMetaDataConfig entityMetaDataConfig;

    @Autowired
    GraphQlTester graphQlTester;

    @BeforeEach
    void initializeTester() {
        Mockito.when(entityMetaDataConfig.getMetaData(ADLEntity.salesOrder)).thenReturn(new EntityMetaData(ADLEntity.salesOrder.name(), "t_mom_sales_order_line_data_p4p", "qa_gold.o2c"));
    }

    @Test
    void salesOrderTest() throws Exception {

        GraphQLQueryResponse response = getMockObject("./response/salesOrder-response.json", GraphQLQueryResponse.class);

        when(queryResolver.search(0, 5, null, null, saleOrderRepository)).thenReturn(response.getSalesOrder());
        graphQlTester.documentName("salesorder-query")
                .execute()
                .path("salesOrders")
                .entityList(SalesOrder.class)
                .hasSize(5);

        Mockito.verify(queryResolver, times(1)).search(0, 5, null, null, saleOrderRepository);
    }




}

*/
