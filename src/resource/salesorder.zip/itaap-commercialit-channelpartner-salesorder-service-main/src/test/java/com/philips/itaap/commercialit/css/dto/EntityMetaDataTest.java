package com.philips.itaap.commercialit.css.dto;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class EntityMetaDataTest {

    @Test
    void hashCodeTestScenario() {
        EntityMetaData entityMetaData = test();
        EntityMetaData entityMetaData1 = test();
        assertEquals(entityMetaData.hashCode(), entityMetaData1.hashCode());
    }


    @Test
    void equalsTestScenario() {
        EntityMetaData entityMetaData = test();
        EntityMetaData entityMetaData1 = test();
        boolean result = entityMetaData.equals(entityMetaData1);
        assertTrue(result);
    }

    @Test
    void equalsTestScenario1() {
        EntityMetaData entityMetaData = test();
        EntityMetaData entityMetaData1 = test();
        entityMetaData.setEntity("SaleOrder");
        entityMetaData.setSchema("test");
        entityMetaData.setTable("salesOrder");
        boolean result = entityMetaData.equals(entityMetaData1);
        assertFalse(result);
    }

    @Test
    void toStringTest() {
        EntityMetaData entityMetaData = test();
        EntityMetaData entityMetaData1 = test();
        assertEquals(entityMetaData.toString(), entityMetaData1.toString());

    }

    public EntityMetaData test() {
        EntityMetaData entityMetaData = new EntityMetaData();
        entityMetaData.setEntity("Salesorder");
        entityMetaData.setSchema("gold");
        entityMetaData.setTable("salesOrder");
        return entityMetaData;
    }
}
