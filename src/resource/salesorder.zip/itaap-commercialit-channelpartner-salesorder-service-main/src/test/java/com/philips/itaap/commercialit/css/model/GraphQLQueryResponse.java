package com.philips.itaap.commercialit.css.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class GraphQLQueryResponse<T> {


    @JsonProperty("salesOrder")
    private List<T> salesOrder;



}

