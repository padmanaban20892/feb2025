package com.philips.itaap.commercialit.css.service;


import com.philips.itaap.commercialit.css.config.ApplicationProperties;
import com.philips.itaap.commercialit.css.jpa.graphqlclient.TokenData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.lang.reflect.Field;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderServiceTokenServiceTest {

    @Mock
    private WebClient orderServiceWebClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.RequestHeadersUriSpec<?> requestHeadersUriSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private ApplicationProperties applicationProperties;

    @InjectMocks
    private OrderServiceTokenService orderServiceTokenService;

    @BeforeEach
    void setUp() throws Exception {
        Field tokenUriField = OrderServiceTokenService.class.getDeclaredField("tokenUri");
        tokenUriField.setAccessible(true);
        tokenUriField.set(orderServiceTokenService, "https://dummy.com");
        when(orderServiceWebClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(any(MediaType.class))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(BodyInserters.FormInserter.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.accept(any(MediaType.class))).thenReturn(requestHeadersSpec);
        ReflectionTestUtils.setField(orderServiceTokenService, "authorizationGrantType", "client_credentials");


    }

    @Test
    void testGetTotaraToken_Success() {
        TokenData mockTokenData = TokenData.builder().failed(false).message("success").build();
        when(requestHeadersSpec.exchangeToMono(any())).thenReturn(Mono.just(mockTokenData));

        Mono<TokenData> tokenDataMono = orderServiceTokenService.getOrderServiceToken();

        StepVerifier.create(tokenDataMono)
                .expectNextMatches(tokenData -> !tokenData.isFailed())
                .verifyComplete();
    }

    @Test
    void testGetTotaraToken_ErrorResponse() {
        TokenData mockTokenData = TokenData.builder().failed(true).message("error_response").build();
        when(requestHeadersSpec.exchangeToMono(any())).thenReturn(Mono.just(mockTokenData));

        Mono<TokenData> tokenDataMono = orderServiceTokenService.getOrderServiceToken();

        StepVerifier.create(tokenDataMono)
                .expectNextMatches(tokenData -> tokenData.isFailed() && "error_response".equals(tokenData.getMessage()))
                .verifyComplete();
    }

    @Test
    void testGetTotaraToken_Exception() {
        when(requestHeadersSpec.exchangeToMono(any())).thenReturn(Mono.error(new WebClientResponseException("500 Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR.value(), "Internal Server Error", null, null, null)));

        Mono<TokenData> tokenDataMono = orderServiceTokenService.getOrderServiceToken();

        StepVerifier.create(tokenDataMono)
                .expectErrorMatches(throwable -> throwable instanceof WebClientResponseException)
                .verify();
    }
}
