package com.philips.itaap.commercialit.css.constants;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class AppConstantsTest {

    @Test
    void testConstant() {
        final AppConstants constants = new AppConstants();
        assertNotNull(constants);
    }
}
