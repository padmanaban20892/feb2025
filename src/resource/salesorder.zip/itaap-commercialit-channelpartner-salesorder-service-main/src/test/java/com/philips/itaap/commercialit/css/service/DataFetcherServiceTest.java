package com.philips.itaap.commercialit.css.service;


import com.philips.itaap.commercialit.css.common.CommonSpecifications;
import com.philips.itaap.commercialit.css.config.ApplicationProperties;
import com.philips.itaap.commercialit.css.controller.DataFetcher;
import com.philips.itaap.commercialit.css.jpa.entity.SalesOrder;
import com.philips.itaap.commercialit.css.jpa.model.OrdersDto;
import com.philips.itaap.commercialit.css.jpa.model.OrdersResponse;
import com.philips.itaap.commercialit.css.jpa.model.SalesOrderConnection;
import com.philips.itaap.commercialit.css.jpa.repository.SalesOrderRepository;
import com.philips.itaap.commercialit.css.utils.TestUtils;
import com.philips.itaap.graphqlbase.common.SortingRule;
import com.philips.itaap.graphqlbase.common.OLAPRepository;
import com.philips.itaap.graphqlbase.common.QueryOperator;
import com.philips.itaap.graphqlbase.common.Filter;
import com.philips.itaap.graphqlbase.common.OLAPSpecifications;

import com.philips.itaap.graphqlbase.service.QueryResolver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import reactor.core.publisher.Flux;


import javax.persistence.EntityManager;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;



import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class DataFetcherServiceTest extends TestUtils {




    @Mock
    private OLAPRepository<SalesOrder, Long> olapRepository;

    @InjectMocks
    private DataFetcherService dataFetcherService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Autowired
    OrderServiceTest orderServiceTest;

    @Mock
    private SalesOrderRepository saleOrderRepository;

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private QueryResolver queryResolver;

    @Test
    public void testGetPaginatedSalesOrders_success() throws IOException {
        // Arrange
        int page = 1;
        int size = 5;
        OrdersDto ordersDto = getMockObject("./entity/orderdto.json", OrdersDto.class);
        SortingRule sortingRule = SortingRule.builder()
                .field("saleOrderItem")
                .order("DESC")
                .build();
        List<SalesOrder> salesOrderList = new ArrayList<>();
        SalesOrder salesOrderItems = getMockObject("./entity/salesorder.json", SalesOrder.class);

        salesOrderList.add(salesOrderItems); // Add mock SalesOrder data
        Page<SalesOrder> pageResult = new PageImpl<>(salesOrderList);
        List<Filter> filterList = new ArrayList<>();


        filterList.add(Filter.builder().field("soldToNo").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());
        filterList.add(Filter.builder().field("customerPurchaseOrderNo").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());
        filterList.add(Filter.builder().field("philipsOrderNo").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());
        filterList.add(Filter.builder().field("salesOrderDate").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());

        List<String> valuesList = new ArrayList<>();
        valuesList.add(ordersDto.getParameters().getStartDate());
        valuesList.add(ordersDto.getParameters().getEndDate());

        filterList.add(Filter.builder().field("salesOrderDate").values(valuesList).operator(QueryOperator.NOT_EQ).build());

        Specification<SalesOrder> specification =  new CommonSpecifications<SalesOrder>().getSpecificationFromFilters(filterList);
        Specification<SalesOrder> specification2 =  new OLAPSpecifications<SalesOrder>().getSpecificationFromFilters(filterList);



       // when(applicationProperties.isSummaryFlag()).thenReturn(false);

//        when(new OLAPSpecifications<SalesOrder>().getSpecificationFromFilters(filterList)).thenReturn(specification2);


       //when(olapRepository.findAll(specification, buildPageRequest(0,5,sortingRule))).thenReturn((Page<SalesOrder>) pageResult);

//        when(queryResolver.search(anyInt(), anyInt(), anyList(), any(), any())).thenReturn(Collections.singletonList(salesOrderList));

        // Act
        Flux<SalesOrderConnection> result = dataFetcherService.getPaginatedSalesOrders(page, size, "c2FsZU9yZGVySXRlbToyMA==", filterList, sortingRule, saleOrderRepository, SalesOrder.class);

       /* // Assert
        StepVerifier.create(result)
                .expectNextMatches(salesOrderConnection -> salesOrderConnection.getSalesOrders().size() == 1)
                .verifyComplete();

        verify(olapRepository, times(1)).findAll(specification, buildPageRequest(0,5,sortingRule));
*/        //verify(queryResolver, times(1)).search(anyInt(), anyInt(), anyList(), any(), any());



    }

    @Test
    public void testGetPaginatedSalesOrders_noData() throws IOException {
        // Arrange
        int page = 1;
        int size = 5;
        OrdersDto ordersDto = getMockObject("./entity/orderdto.json", OrdersDto.class);
        SortingRule sortingRule = SortingRule.builder()
                .field("saleOrderItem")
                .order("DESC")
                .build();
        List<SalesOrder> salesOrderList = new ArrayList<>();
        SalesOrder salesOrderItems = getMockObject("./entity/salesorder.json", SalesOrder.class);

        salesOrderList.add(salesOrderItems); // Add mock SalesOrder data
        Page<SalesOrder> pageResult = new PageImpl<>(salesOrderList);
        List<Filter> filterList = new ArrayList<>();


        filterList.add(Filter.builder().field("soldToNo").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());
        filterList.add(Filter.builder().field("customerPurchaseOrderNo").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());
        filterList.add(Filter.builder().field("philipsOrderNo").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());
        filterList.add(Filter.builder().field("salesOrderDate").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());

        List<String> valuesList = new ArrayList<>();
        valuesList.add(ordersDto.getParameters().getStartDate());
        valuesList.add(ordersDto.getParameters().getEndDate());

        filterList.add(Filter.builder().field("salesOrderDate").values(valuesList).operator(QueryOperator.NOT_EQ).build());

        Specification<SalesOrder> specification =  new CommonSpecifications<SalesOrder>().getSpecificationFromFilters(filterList);





        when(olapRepository.findAll(specification, buildPageRequest(0, 5, null))).thenReturn(pageResult);

        // when(queryResolver.search(anyInt(), anyInt(), anyList(), any(), any())).thenReturn(salesOrderList);

        // Act
        Flux<SalesOrderConnection> result = dataFetcherService.getPaginatedSalesOrders(page, size, null, filterList, null, olapRepository, SalesOrder.class);

        // Assert
        /*StepVerifier.create(result)
                .expectNextMatches(salesOrderConnection -> salesOrderConnection.getSalesOrders().isEmpty())
                .verifyComplete();

        verify(olapRepository, times(1)).findAll(specification, buildPageRequest(0,5,sortingRule));
*/    }

    @Test
    public void testGetPaginatedSalesOrders_exception() {
        // Arrange
        int page = 1;
        int size = 5;
        SortingRule sortingRule = SortingRule.builder()
                .field("saleOrderItem")
                .order("DESC")
                .build();
        List<Filter> filterList = new ArrayList<>();


        Specification<SalesOrder> specification =  new CommonSpecifications<SalesOrder>().getSpecificationFromFilters(filterList);


       Mockito.when(olapRepository.findAll(specification, buildPageRequest(0, 5, sortingRule)))
               .thenThrow(new RuntimeException("Database error"));

        Flux<SalesOrderConnection> result = dataFetcherService.getPaginatedSalesOrders(page, size, null, filterList, sortingRule, olapRepository, SalesOrder.class);

        // Assert
        /*StepVerifier.create(result)
                .expectErrorMatches(throwable -> throwable instanceof ServiceException &&
                        ((ServiceException) throwable).getStatus().value() == HttpStatus.BAD_REQUEST.value())
                .verify();

        verify(olapRepository, times(1)).findAll(specification, buildPageRequest(0,5,sortingRule));
    */}

    @Mock
    private Page<SalesOrder> listPage;

    /*public void testGetSaleOrderByADL_success() throws IOException {
        MockitoAnnotations.openMocks(this);
        // Arrange
        int page = 1;
        int size = 5;
        OrdersDto ordersDto = getMockObject("./entity/orderdto.json", OrdersDto.class);
        SortingRule sortingRule = SortingRule.builder()
                .field("saleOrderItem")
                .order("DESC")
                .build();

        SalesOrder salesOrderItems = getMockObject("./entity/salesorder.json", SalesOrder.class);
        SalesOrder salesOrderItems2 = getMockObject("./entity/salesorder2.json", SalesOrder.class);
        List<SalesOrder> salesOrderList = Arrays.asList(salesOrderItems2, salesOrderItems);
        Page<SalesOrder> pageResult = new PageImpl<>(salesOrderList);
        List<Filter> filterList = new ArrayList<>();


        filterList.add(Filter.builder().field("soldToNo").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());
        filterList.add(Filter.builder().field("customerPurchaseOrderNo").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());
        filterList.add(Filter.builder().field("philipsOrderNo").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());
        filterList.add(Filter.builder().field("salesOrderDate").values(ordersDto.getParameters().getSoldToPartnerNumber()).operator(QueryOperator.IN).build());

        List<String> valuesList = new ArrayList<>();
        valuesList.add(ordersDto.getParameters().getStartDate());
        valuesList.add(ordersDto.getParameters().getEndDate());

        filterList.add(Filter.builder().field("salesOrderDate").values(valuesList).operator(QueryOperator.NOT_EQ).build());

        Specification<SalesOrder> specification =  new CommonSpecifications<SalesOrder>().getSpecificationFromFilters(filterList);


        when(olapRepository.findAll(specification, dataFetcherService.pageRequest(0, 5 , AppConstants.PHILIPSORDERNO))).thenReturn(pageResult);
       when(listPage.isEmpty()).thenReturn(false);
        when(listPage.getContent()).thenReturn(salesOrderList);
       when(listPage.get()).thenReturn(salesOrderList.stream());



        // Act
        //Mono<SalesOrderConnection> result = dataFetcherService.getSaleOrderByADL(page, size, filterList, sortingRule, saleOrderRepository, SalesOrder.class);

        List<String> pageString = Arrays.asList("6308190119", "6307893165", "6308337389");
        Page<String> pageStringResult = new PageImpl<>(pageString);


        Mockito.when(saleOrderRepository.findDistinctPhilipsOrderNumberBySalesOrderNumber(
                dataFetcherService.pageRequest(0, 5, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY))).thenReturn(pageStringResult);
       // Mono<SalesOrderConnection> resultNativeQuery = dataFetcherService.getSaleOrderByADLWithNativeQuery(page, size, filterList,
         //       sortingRule, olapRepository, SalesOrder.class);



    }*/

    @Mock
    EntityManager entityManager;

    /*public void testGetSaleOrderByADL_noData() throws IOException {
        // Arrange
        int page = 1;
        int size = 5;
        List<Filter> filters = new ArrayList<>();
        SortingRule sortingRule = SortingRule.builder()
                .field("saleOrderItem")
                .order("DESC")
                .build();
        List<SalesOrder> salesOrderList = new ArrayList<>();
        SalesOrder salesOrderItems = getMockObject("./entity/salesorder.json", SalesOrder.class);
        salesOrderList.add(salesOrderItems);
        salesOrderItems = getMockObject("./entity/salesorder2.json", SalesOrder.class);
        salesOrderList.add(salesOrderItems);
        Page<SalesOrder> pageResult = new PageImpl<>(salesOrderList);
        Specification<SalesOrder> specification =  new CommonSpecifications<SalesOrder>().getSpecificationFromFilters(filters);


        when(olapRepository.findAll(specification, buildPageRequest(0,5,sortingRule))).thenReturn(pageResult);

        // Act
        Mono<SalesOrderConnection> result = dataFetcherService.getSaleOrderByADL(page, size, filters, sortingRule, saleOrderRepository, SalesOrder.class);

        // Assert
        *//*StepVerifier.create(result)
                .expectNextMatches(salesOrderConnection -> salesOrderConnection.getSalesOrders().isEmpty())
                .verifyComplete();

        verify(olapRepository, times(1)).findAll(specification, buildPageRequest(0,5,sortingRule));
*//*
    }*/

    /*@Test
    public void testGetSaleOrderByADL_exception() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        // Arrange
        int page = 1;
        int size = 5;
        List<Filter> filters = new ArrayList<>();
        SortingRule sortingRule = SortingRule.builder()
                .field("saleOrderItem")
                .order("DESC")
                .build();


        Specification<SalesOrder> specification =  new CommonSpecifications<SalesOrder>().getSpecificationFromFilters(filters);



        Mockito.when(olapRepository.findAll(specification, dataFetcherService.pageRequest(0, 5, AppConstants.PHILIPSORDERNO)))
                .thenThrow(new RuntimeException("ADL service error"));

        // Act
       // Mono<SalesOrderConnection> result = dataFetcherService.getSaleOrderByADL(page, size, filters, sortingRule, olapRepository, SalesOrder.class);
        List<String> pageString = Arrays.asList("6308190119", "6307893165", "6308337389");
        Page<String> pageResult = new PageImpl<>(pageString);

        Mockito.when(saleOrderRepository.findDistinctPhilipsOrderNumberBySalesOrderNumber(
                dataFetcherService.pageRequest(0, 5, AppConstants.PHILIPS_ORDER_NUMBER_ENTITY))).thenReturn(pageResult);
      //  Mono<SalesOrderConnection> resultNativeQuery = dataFetcherService.getSaleOrderByADLWithNativeQuery(page, size, filters,
        //        sortingRule, olapRepository, SalesOrder.class);




        // Assert
        *//*StepVerifier.create(result)
                .expectErrorMatches(throwable -> throwable instanceof ServiceException &&
                        ((ServiceException) throwable).getStatus().value() == HttpStatus.BAD_REQUEST.value())
                .verify();

        verify(olapRepository, times(1)).findAll(specification, buildPageRequest(0,5,sortingRule));
    *//*





    }*/


    private Pageable buildPageRequest(int page, int size, SortingRule sortingRule) {
        PageRequest pageRequest;
        if (Objects.isNull(sortingRule)) {
            pageRequest = PageRequest.of(page, size);
        } else {
            pageRequest = PageRequest.of(page, size,
                    Sort.by(Sort.Direction.valueOf(sortingRule.getOrder()), sortingRule.getField()));
        }
        return pageRequest;
    }

    @Mock
    DataFetcherService dataFetcher;

    @InjectMocks
    DataFetcher dataFetcherCtrl;

    @Test
    public void testDataFetcher() throws IOException {
        int page = 1;
        int size = 5;
        SortingRule sortingRule = SortingRule.builder()
                .field("saleOrderItem")
                .order("DESC")
                .build();
        List<Filter> filterList = new ArrayList<>();


        SalesOrderConnection salesOrderConnection = getMockObject("entity/salesOrderConnection.json", SalesOrderConnection.class);
        OrdersResponse ordersResponse = getMockObject("./entity/ordersreponse.json", OrdersResponse.class);


        List<SalesOrderConnection> salesOrderConnectionList = new ArrayList<>();
        salesOrderConnectionList.add(salesOrderConnection);

        List<OrdersResponse> ordersResponseList = new ArrayList<>();
        ordersResponseList.add(ordersResponse);
        Flux<SalesOrderConnection> expOrdersResponseFlux = Flux.just(salesOrderConnectionList).flatMapIterable(list -> list);

        //dataFetcherService.getPaginatedSalesOrders(page, size, after, filters, sortRule, saleOrderRepository, SalesOrder.class);


        /*when(dataFetcher.getPaginatedSalesOrders(page, size, null, filterList, sortingRule, saleOrderRepository, SalesOrder.class))
                .thenReturn(expOrdersResponseFlux);*/

        Flux<SalesOrderConnection> expOrdersResponse =  dataFetcherCtrl.paginatedSalesOrders(page, size, null, filterList, sortingRule);


    }
}