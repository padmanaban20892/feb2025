package com.philips.itaap.commercialit.css.config;

import com.philips.itaap.commercialit.css.dto.ADLEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@ActiveProfiles("test")
@ExtendWith(SpringExtension.class)
public class EntityMetaDataConfigTest {

    @Configuration
    @EnableConfigurationProperties(EntityMetaDataConfig.class)
    static class Config {
        @Bean
        public EntityMetaDataConfig entityMetaDataConfig() {
            return new EntityMetaDataConfig();
        }
    }

    @Autowired
    EntityMetaDataConfig entityMetaDataConfig;

    @Test
    void hashCodeTestScenario() {
        EntityMetaDataConfig entityMetaDataConfig = test();
        EntityMetaDataConfig entityMetaDataConfig1 = test();
        assertEquals(entityMetaDataConfig.hashCode(), entityMetaDataConfig1.hashCode());
    }

    @Test
    void equalsTestScenario() {
        EntityMetaDataConfig entityMetaDataConfig = test();
        EntityMetaDataConfig entityMetaDataConfig1 = test();
        boolean result = entityMetaDataConfig.equals(entityMetaDataConfig1);
        assertTrue(result);
    }

    @Test
    void equalsTestScenario1() {
        EntityMetaDataConfig entityMetaDataConfig = new EntityMetaDataConfig();
        EntityMetaDataConfig entityMetaDataConfig1 = test();
        EntityMetaDataConfig entityMetaData = new EntityMetaDataConfig();
        //entityMetaData.setTable("customers");
        entityMetaDataConfig.setMetadata(entityMetaData.toString());
        entityMetaDataConfig.setEntityMetaDataMap(new HashMap<>());
        boolean result = entityMetaDataConfig.equals(entityMetaDataConfig1);
        assertFalse(result);
    }

    @Test
    void constructorEqualsTestScenario() {
        EntityMetaDataConfig entityMetaDataConfig = test();
        EntityMetaDataConfig entityMetaDataConfig1 = new EntityMetaDataConfig();
        boolean result = entityMetaDataConfig.equals(entityMetaDataConfig1);
        assertFalse(result);
    }

    @Test
    void toStringTest() {
        EntityMetaDataConfig entityMetaData = test();
        EntityMetaDataConfig entityMetaData1 = test();
        assertEquals(entityMetaData.toString(), entityMetaData1.toString());
    }

    @Test
    void getMetaDataTest() {
        String table = entityMetaDataConfig.getMetaData(ADLEntity.salesOrder).getTable();
        assertEquals(table, "t_mom_sales_order_line_data_p4p");
    }

    public EntityMetaDataConfig test() {
        EntityMetaDataConfig entityMetaDataConfig = new EntityMetaDataConfig();
        EntityMetaDataConfig entityMetaData = new EntityMetaDataConfig();
    //    entityMetaData.setEntity("customers");
        entityMetaDataConfig.setMetadata(entityMetaData.toString());
        return entityMetaDataConfig;
    }
}
