package com.philips.itaap.commercialit.css.service;


import com.philips.itaap.commercialit.css.config.ApplicationProperties;
import com.philips.itaap.commercialit.css.constants.AppConstants;
import com.philips.itaap.commercialit.css.controller.OrderController;
import com.philips.itaap.commercialit.css.jpa.model.SalesOrderConnection;
import com.philips.itaap.commercialit.css.jpa.model.email.CPMSummary;
import com.philips.itaap.commercialit.css.jpa.model.PageInfo;
import com.philips.itaap.commercialit.css.jpa.model.OrdersDto;
import com.philips.itaap.commercialit.css.jpa.model.OrdersResponse;
import com.philips.itaap.commercialit.css.jpa.repository.SalesOrderRepository;
import com.philips.itaap.commercialit.css.utils.TestUtils;
import com.philips.itaap.graphqlbase.common.Filter;
import com.philips.itaap.graphqlbase.common.QueryOperator;
import com.philips.itaap.graphqlbase.common.SortingRule;
import com.philips.itaap.ms.dev.base.exception.ServiceException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.TraceContext;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.util.retry.Retry;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;


import static com.philips.itaap.commercialit.css.constants.AppConstants.MYP4P;
import static com.philips.itaap.commercialit.css.constants.FlowName.ORDER_SERVICE;
import static com.philips.itaap.commercialit.css.util.JsonMapper.getTraceId;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class OrderServiceTest extends TestUtils {
    public static final String ORDER_SALES = "/orders";

    @Mock
    private WebClient webClientEmail;

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private Retry attemptRetry;
    @InjectMocks
    private OrderService orderService;
    @Mock
    private Tracer tracer;
    @Mock
    private Span span;
    @Mock
    private TraceContext context;

    @InjectMocks
    private EmailService emailService;
    @Mock
    private SalesOrderRepository repository;

    @Mock
    private DataFetcherService dataFetcherService;


    @Mock
    private AppConstants appConstants;

    @InjectMocks
    private OrderController orderController;


    private void mockTraceId() {
        Mockito.when(tracer.currentSpan()).thenReturn(span);
        Mockito.when(span.context()).thenReturn(context);
        Mockito.when(context.traceId()).thenReturn("a9d18095-3c52-45f2-b622-223d9da55a31");
    }


    @Test
    void testOrdersDetailWithEmpty() throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        mockTraceId();
        OrdersDto ordersDto = test();
        ordersDto.getParameters().setEndDate(null);
        assertThrows(ServiceException.class, () -> {
            orderService.ordersDetail(ordersDto, ORDER_SALES);
        });

        ordersDto.getParameters().setEndDate("2024-08-20");
        ordersDto.getParameters().setStartDate("2025-08-20");
        assertThrows(ServiceException.class, () -> {
            orderService.ordersDetail(ordersDto, ORDER_SALES);
        });

        SalesOrderConnection salesOrderConnection = getMockObject("entity/salesOrderConnection.json", SalesOrderConnection.class);

        salesOrderConnection.setSalesOrders(new ArrayList<>(0));
        salesOrderConnection.setPageInfo(new PageInfo());


        List<SalesOrderConnection> salesOrderConnectionList = new ArrayList<>();
        salesOrderConnectionList.add(salesOrderConnection);


        Method privateMethod = OrderService.class.getDeclaredMethod("processSaleOrderDetails", List.class, CPMSummary.class);
        privateMethod.setAccessible(true);
        // List<SalesOrderConnection> salesOrderConnectionResult = (List<SalesOrderConnection>) privateMethod.invoke(orderService, salesOrderConnectionList, cpmSummaryBuilder());

        assertThrows(InvocationTargetException.class, () -> {

            privateMethod.invoke(orderService, salesOrderConnectionList, cpmSummaryBuilder());


        });

        List<SalesOrderConnection> salesOrderConnectionList2 = new ArrayList<>(0);

        assertThrows(InvocationTargetException.class, () -> {

            privateMethod.invoke(orderService, salesOrderConnectionList2, cpmSummaryBuilder());

        });


        Method privateMethod2 = OrderService.class.getDeclaredMethod("convertOrdersFromSalesOrderList", List.class, CPMSummary.class);
        privateMethod2.setAccessible(true);

        assertThrows(InvocationTargetException.class, () -> {

            privateMethod2.invoke(orderService, salesOrderConnectionList, cpmSummaryBuilder());

        });


    }

    private Object cpmSummaryBuilder() {
        mockTraceId();
        return CPMSummary.builder()
                .correlationId(getTraceId(tracer))
                .startTime(Calendar.getInstance().getTime().toString())
                .flowName(ORDER_SERVICE.getName())
                .sourceSystem(MYP4P)
                .endpoint(ORDER_SALES)
                .failed(false)
                .build();
    }

    @Test
    void testOrdersDetailWithValidData() throws IOException {
        mockTraceId();
        OrdersDto ordersDto = getMockObject("model/orderDto.json", OrdersDto.class);
        Flux<OrdersResponse> responseFlux = orderService.ordersDetail(ordersDto, ORDER_SALES);
        assertNotNull(responseFlux);
    }


    @Test
    void testOrdersDetailsWithDateValidator() throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {

        OrdersDto ordersDto = test();


        Method privateMethod = OrderService.class.getDeclaredMethod("dateValidator", OrdersDto.class);
        privateMethod.setAccessible(true);

        boolean isDate = (boolean) privateMethod.invoke(orderService, ordersDto);
        assertEquals(false, isDate);


    }


    @Test
    void ordersDetailsFromSalesOrderServiceTest() throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        mockTraceId();
        OrdersDto ordersDto = test();
        SalesOrderConnection salesOrderConnection = getMockObject("entity/salesOrderConnection.json", SalesOrderConnection.class);
        OrdersResponse ordersResponse = getMockObject("./entity/ordersreponse.json", OrdersResponse.class);

        SortingRule sortingRule = SortingRule.builder()
                .field("saleOrderItem")
                .order("DESC")
                .build();
        int page = 1;
        int size = 5;
        List<Filter> filterList = new ArrayList<>();
        filterList.add(filterBuilder("soldToNo", ordersDto.getParameters().getSoldToPartnerNumber()));
        filterList.add(filterBuilder("customerPurchaseOrderNo", ordersDto.getParameters().getPartnerPO()));
        filterList.add(filterBuilder("philipsOrderNo", ordersDto.getParameters().getSalesOrder()));
        filterList.add(filterBuilderValue("salesOrderDate", ordersDto.getParameters().getStartDate(),
                ordersDto.getParameters().getEndDate()));

        Mockito.when(applicationProperties.getLimit()).thenReturn(5);

        Mono<SalesOrderConnection> salesOrderConnectionMono = Mono.just(salesOrderConnection);

      /*  Mockito.when(dataFetcherService.getSaleOrderByADL(page, size, filterList,
                sortingRule, repository, SalesOrder.class)).thenReturn(salesOrderConnectionMono);
*/

        List<SalesOrderConnection> salesOrderConnectionList = new ArrayList<>();
        salesOrderConnectionList.add(salesOrderConnection);

        List<OrdersResponse> ordersResponseList = new ArrayList<>();
        ordersResponseList.add(ordersResponse);


        Method processSaleOrderMethod = OrderService.class.getDeclaredMethod("processSaleOrderDetails", List.class, CPMSummary.class);
        processSaleOrderMethod.setAccessible(true);

        List<OrdersResponse> ordersResponseResult = (List<OrdersResponse>) processSaleOrderMethod.invoke(orderService, salesOrderConnectionList, cpmSummaryBuilder());

        assertTrue(ordersResponseResult.size() == 1, String.valueOf(ordersResponseList.size() == 1));


        //write test cases for private methods for ordersDetailsFromSalesOrderService()
        Method privateMethod = OrderService.class.getDeclaredMethod("ordersDetailsFromSalesOrderService", OrdersDto.class);
        privateMethod.setAccessible(true);

        Mono<SalesOrderConnection> salesOrderConnectionMono2 = (Mono<SalesOrderConnection>) privateMethod.invoke(orderService, ordersDto);
//        assertEquals(salesOrderConnectionMono, salesOrderConnectionMono2);
        // StepVerifier.create(salesOrderConnectionMono2).expectNextMatches((Predicate<? super SalesOrderConnection>) salesOrderConnectionMono).verifyComplete();
       // StepVerifier.create(salesOrderConnectionMono2).expectNextCount(1).verifyComplete();

        //ordersDetail method
        Flux<OrdersResponse> expOrdersResponseFlux = Flux.just(ordersResponseList).flatMapIterable(list -> list);

        Flux<OrdersResponse> responseFlux = orderService.ordersDetail(ordersDto, ORDER_SALES);
        //assertEquals(ordersResponseFlux, ordersResponseFluxResult);



        //  StepVerifier.create(responseFlux).expectNextMatches((Predicate<? super OrdersResponse>) expOrdersResponseFlux).verifyComplete();

        //StepVerifier.create(responseFlux).consumeNextWith(Assertions::assertNotNull).verifyComplete();


    }

    public Filter filterBuilderValue(String field, String value, String value2) {
        List<String> valuesList = new ArrayList<>();
        valuesList.add(value);
        valuesList.add(value2);

        return Filter.builder().field(field)
                .values(valuesList)
                .operator(QueryOperator.NOT_EQ) //Date specified - between of two dates
                .build();
    }

    public Filter filterBuilder(String field, List<String> valuesList) {
        return Filter.builder().field(field)
                .values(valuesList)
                .operator(QueryOperator.IN)
                .build();
    }

    public OrdersDto test() throws IOException {
        return getMockObject("./entity/orderdto.json", OrdersDto.class);
    }


   /* @Test
    public void testOrdersDetailsWithEmail() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        Mockito.when(applicationProperties.isSummaryFlag()).thenReturn(true);
        Mono<EmailResponse> emailResponseMono = Mono.just(new EmailResponse());


        Mockito.when(emailService.createSupportEmailAndSend(0, 5,
                "test mail", EmailServiceTest.class,
                "test desc", "Invalid test")).thenReturn(emailResponseMono);




        Method privateMethod = OrderService.class.getDeclaredMethod("ordersDetailsFromSalesOrderService", Integer.class,
                Integer.class, String.class, SalesOrder.class, String.class, String.class);
        privateMethod.setAccessible(true);



        Mono<EmailResponse> emailResponseResult = (Mono<EmailResponse>) privateMethod.invoke(orderService, 0, 5,
                "test mail", SalesOrder.class, "test desc", "Invalid test");

        StepVerifier.create(emailResponseResult).consumeNextWith(Assertions::assertNotNull).verifyComplete();






    }
*/ @Mock
   OrderService orderService1;
    @Test
    public void testOrderController() throws IOException {
        //mockTraceId();
        OrdersDto ordersDto = test();
        SalesOrderConnection salesOrderConnection = getMockObject("entity/salesOrderConnection.json", SalesOrderConnection.class);
        OrdersResponse ordersResponse = getMockObject("./entity/ordersreponse.json", OrdersResponse.class);


        List<SalesOrderConnection> salesOrderConnectionList = new ArrayList<>();
        salesOrderConnectionList.add(salesOrderConnection);

        List<OrdersResponse> ordersResponseList = new ArrayList<>();
        ordersResponseList.add(ordersResponse);
        Flux<OrdersResponse> expOrdersResponseFlux = Flux.just(ordersResponseList).flatMapIterable(list -> list);


        Mockito.when(applicationProperties.getApiFetchOrdersDetails()).thenReturn(ORDER_SALES);


        Mockito.when(orderService1.ordersDetail(ordersDto, ORDER_SALES)).thenReturn(expOrdersResponseFlux);



        Flux<OrdersResponse> ordersResponseFlux = orderController.ordersDetail(ordersDto);

        StepVerifier.create(ordersResponseFlux).consumeNextWith(Assertions::assertNotNull).verifyComplete();

    }
}


