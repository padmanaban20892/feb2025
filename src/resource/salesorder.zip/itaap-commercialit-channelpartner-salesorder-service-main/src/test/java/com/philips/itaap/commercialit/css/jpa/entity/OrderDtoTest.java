package com.philips.itaap.commercialit.css.jpa.entity;


import com.philips.itaap.commercialit.css.jpa.model.OrdersDto;
import com.philips.itaap.commercialit.css.utils.TestUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class OrderDtoTest extends TestUtils {
    @Test
    void hashCodeTestScenario() throws IOException {
        OrdersDto data = test();
        OrdersDto data2 = test();
        assertEquals(data.hashCode(), data2.hashCode());
    }

    public OrdersDto test() throws IOException {
        return getMockObject("./entity/orderdto.json", OrdersDto.class);
    }

    @Test
    void equalsTestOrdersDtoScenario() throws IOException {
        OrdersDto data = test();
        OrdersDto data2 = test();
        boolean result = data.equals(data2);
        assertTrue(result);
    }

    @Test
    void toStringTest() throws IOException {
        OrdersDto data = test();
        OrdersDto data2 = test();
        assertEquals(data.toString(), data2.toString());

    }
}
