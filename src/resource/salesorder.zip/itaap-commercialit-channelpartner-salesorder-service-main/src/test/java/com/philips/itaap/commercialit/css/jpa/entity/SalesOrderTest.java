package com.philips.itaap.commercialit.css.jpa.entity;


import com.philips.itaap.commercialit.css.utils.TestUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class SalesOrderTest extends TestUtils {

    @Test
    void hashCodeTestScenario() throws IOException {
        SalesOrder salesOrderItems = test();
        SalesOrder salesOrderItems1 = test();
        assertEquals(salesOrderItems.hashCode(), salesOrderItems1.hashCode());
    }


    @Test
    void equalsTestScenario() throws IOException {
        SalesOrder salesOrderItems = test();
        SalesOrder salesOrderItems1 = test();
        boolean result = salesOrderItems.equals(salesOrderItems1);
        assertTrue(result);
    }

    @Test
    void equalsTestScenario1() throws IOException {
        SalesOrder salesOrderItems = test();
        SalesOrder salesOrderItems1 = test();
        salesOrderItems.setSoldToNo("123");
        boolean result = salesOrderItems.equals(salesOrderItems1);
        assertFalse(result);
    }

    @Test
    void toStringTest() throws IOException {
        SalesOrder salesOrderItems = test();
        SalesOrder salesOrderItems1 = test();
        assertEquals(salesOrderItems.toString(), salesOrderItems1.toString());

    }

    public SalesOrder test() throws IOException {
        return getMockObject("./entity/salesorder.json", SalesOrder.class);
    }
}

