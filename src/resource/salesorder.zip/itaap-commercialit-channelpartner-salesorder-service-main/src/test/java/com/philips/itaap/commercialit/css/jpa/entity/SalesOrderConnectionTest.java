package com.philips.itaap.commercialit.css.jpa.entity;
import com.philips.itaap.commercialit.css.jpa.model.SalesOrderConnection;
import com.philips.itaap.commercialit.css.utils.TestUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
public class SalesOrderConnectionTest extends TestUtils {

    @Test
    void hashCodeTestScenario() throws IOException {
        SalesOrderConnection data = test();
        SalesOrderConnection data2 = test();
        assertEquals(data.hashCode(), data2.hashCode());
    }

    public SalesOrderConnection test() throws IOException {
        return getMockObject("entity/salesOrderConnection.json", SalesOrderConnection.class);
    }


}
