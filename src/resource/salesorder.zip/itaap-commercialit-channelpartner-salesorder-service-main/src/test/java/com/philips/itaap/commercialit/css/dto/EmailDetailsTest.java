package com.philips.itaap.commercialit.css.dto;

import org.junit.jupiter.api.Test;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class EmailDetailsTest {

    @Test
    void hashCodeTestScenario() {
        EmailDetails emailDetails = test();
        EmailDetails emailDetails1 = test();
        assertEquals(emailDetails.hashCode(), emailDetails1.hashCode());
    }


    @Test
    void equalsTestScenario() {
        EmailDetails emailDetails = test();
        EmailDetails emailDetails1 = test();
        boolean result = emailDetails.equals(emailDetails1);
        assertTrue(result);
    }

    @Test
    void equalsTestScenario1() {
        EmailDetails emailDetails = test();
        EmailDetails emailDetails1 = test();
        emailDetails.setSubject("Unit Testing1");
        boolean result = emailDetails.equals(emailDetails1);
        assertFalse(result);
    }

    @Test
    void toStringTest() {
        EmailDetails emailDetails = test();
        EmailDetails emailDetails1 = test();
        assertEquals(emailDetails.toString(), emailDetails1.toString());

    }

    public EmailDetails test() {
        EmailDetails emailDetails = new EmailDetails();
        emailDetails.setSubject("Unit Testing");
        emailDetails.setBody("Unit Testing");
        emailDetails.setCc(Collections.emptyList());
        emailDetails.setTo(Collections.emptyList());
        return emailDetails;
    }
}
