package com.philips.itaap.commercialit.css.jpa.entity;

import com.philips.itaap.commercialit.css.jpa.model.OrdersResponse;
import com.philips.itaap.commercialit.css.utils.TestUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class OrderResponseTest  extends TestUtils {
    @Test
    void hashCodeTestScenario() throws IOException {
        OrdersResponse data = test();
        OrdersResponse data2 = test();
        assertEquals(data.hashCode(), data2.hashCode());
    }

    public OrdersResponse test() throws IOException {
        return getMockObject("./entity/ordersreponse.json", OrdersResponse.class);
    }

    @Test
    void equalsTestOrdersDtoScenario() throws IOException {
        OrdersResponse data = test();
        OrdersResponse data2 = test();
        boolean result = data.equals(data2);
        assertTrue(result);
    }

    @Test
    void toStringTest() throws IOException {
        OrdersResponse data = test();
        OrdersResponse data2 = test();
        assertEquals(data.toString(), data2.toString());

    }
}
